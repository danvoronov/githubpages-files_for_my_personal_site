<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1201790233279" ID="Freemind_Link_86798810" MODIFIED="1201790233279" TEXT="&#x422;&#x430;&#x439;&#x43c;-&#x434;&#x440;&#x430;&#x439;&#x432;&#xa;(&#x413;&#x43b;&#x435;&#x431; &#x410;&#x440;&#x445;&#x430;&#x43d;&#x433;&#x435;&#x43b;&#x44c;&#x441;&#x43a;&#x438;&#x439;)">
<hook NAME="accessories/plugins/NodeNote.properties">
<text>&#x418;&#x437;&#x434;&#x430;&#x43d;&#x438;&#x435; &#x43f;&#x435;&#x440;&#x432;&#x43e;&#x435;, 2005 &#x433;&#x43e;&#x434;&lt;br&gt;&lt;br&gt;ISBN: 5-902862-05-1&lt;br&gt;&lt;br&gt;http://www.livelib.ru/book/1000261512&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&#x410;&#x432;&#x442;&#x43e;&#x440; mindmap&apos;&#x430; - &#x414;&#x430;&#x43d; &#x412;&#x43e;&#x440;&#x43e;&#x43d;&#x43e;&#x432; (www.dan.kiev.ua), 2008 &#x433;&#x43e;&#x434;.</text>
</hook>
<node CREATED="1201790233280" ID="Freemind_Link_1914042577" MODIFIED="1201790233280" POSITION="right" TEXT="&#x41c;&#x44b;&#x448;&#x43b;&#x435;&#x43d;&#x438;&#x435;">
<node CREATED="1201790233280" FOLDED="true" ID="Freemind_Link_1285266148" MODIFIED="1201790233280" TEXT="&#x433;&#x43b;1: &#x41e;&#x442;&#x434;&#x44b;&#x445;">
<node CREATED="1201790233280" MODIFIED="1201790233280" TEXT="&#x420;&#x438;&#x442;&#x43c;&#x438;&#x447;&#x43d;&#x43e;"/>
<node CREATED="1201790233280" FOLDED="true" ID="Freemind_Link_582026689" MODIFIED="1201790233280" TEXT="&#x424;&#x438;&#x437;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x438;&#x439;">
<node CREATED="1201790233280" MODIFIED="1201790233280" TEXT="&#x410;&#x43a;&#x442;&#x438;&#x432;&#x43d;&#x44b;&#x439;"/>
</node>
<node CREATED="1201790233280" FOLDED="true" ID="Freemind_Link_1196860182" MODIFIED="1201790233280" TEXT="&#x422;&#x432;&#x43e;&#x440;&#x447;&#x435;&#x441;&#x43a;&#x430;&#x44f; &#x43b;&#x435;&#x43d;&#x44c;">
<node CREATED="1201790233280" MODIFIED="1201790233280" TEXT="&#x41d;&#x430; 100%"/>
<node CREATED="1201790233280" FOLDED="true" ID="Freemind_Link_614529369" MODIFIED="1201790233280" TEXT="&#x414;&#x43e;">
<node CREATED="1201790233280" MODIFIED="1201790233280" TEXT="&#x423;&#x441;&#x43b;&#x43e;&#x432;&#x438;&#x44f; &#x441;&#x43b;&#x43e;&#x436;&#x43d;&#x43e;&#x439; &#x437;&#x430;&#x434;&#x430;&#x447;&#x438;"/>
</node>
</node>
<node CREATED="1201790233280" FOLDED="true" ID="Freemind_Link_1191480879" MODIFIED="1201790233280" TEXT="&#x421;&#x43e;&#x43d;">
<node CREATED="1201790233280" MODIFIED="1201790233280" TEXT="&#x41e;&#x442;&#x445;&#x43e;&#x434;"/>
<node CREATED="1201790233280" MODIFIED="1201790233280" TEXT="&#x41f;&#x440;&#x438;&#x445;&#x43e;&#x434;"/>
<node CREATED="1201790233281" MODIFIED="1201790233281" TEXT="&#x414;&#x43d;&#x435;&#x432;&#x43d;&#x43e;&#x439;"/>
<node CREATED="1201790233281" MODIFIED="1201790233281" TEXT="&#x420;&#x438;&#x442;&#x43c;&#x44b;"/>
</node>
<node CREATED="1201790233281" FOLDED="true" ID="Freemind_Link_1482687318" MODIFIED="1201790233281" TEXT="&#x41e;&#x441;&#x43e;&#x437;&#x43d;&#x430;&#x43d;&#x43d;&#x43e;&#x441;&#x442;&#x44c;">
<node CREATED="1201790233281" MODIFIED="1201790233281" TEXT="&#x41f;&#x435;&#x440;&#x435;&#x436;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x43c;&#x43e;&#x43c;&#x435;&#x43d;&#x442;&#x430;"/>
<node CREATED="1201790233281" FOLDED="true" ID="Freemind_Link_530848861" MODIFIED="1201790233281" TEXT="&#x41d;&#x430; &#x43f;&#x43e;&#x43b;&#x43d;&#x443;&#x44e;">
<node CREATED="1201790233281" MODIFIED="1201790233281" TEXT="&#x41a;&#x430;&#x447;&#x435;&#x441;&#x442;&#x432;&#x43e;"/>
</node>
</node>
</node>
<node CREATED="1201790233281" FOLDED="true" ID="Freemind_Link_1805181684" MODIFIED="1201790233281" TEXT="&#x433;&#x43b;2: &#x41c;&#x43e;&#x442;&#x438;&#x432;&#x430;&#x446;&#x438;&#x44f;">
<node CREATED="1201790233281" FOLDED="true" ID="Freemind_Link_1380240089" MODIFIED="1201790233281" TEXT="&#x412;&#x43a;&#x43b;&#x44e;&#x447;&#x435;&#x43d;&#x438;&#x435; &#x432; &#x440;&#x430;&#x431;&#x43e;&#x442;&#x443;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233281" FOLDED="true" ID="Freemind_Link_388230889" MODIFIED="1201790233281" TEXT="&#x42f;&#x43a;&#x43e;&#x440;&#x435;&#x43c;">
<node CREATED="1201790233281" MODIFIED="1201790233281" TEXT="&#x41c;&#x443;&#x437;&#x44b;&#x43a;&#x430;"/>
<node CREATED="1201790233281" MODIFIED="1201790233281" TEXT="&#x41f;&#x440;&#x43e;&#x441;&#x442;&#x43e;&#x435; &#x434;&#x435;&#x439;&#x441;&#x442;&#x432;&#x438;&#x435;"/>
</node>
<node CREATED="1201790233281" MODIFIED="1201790233281" TEXT="&#x41c;&#x430;&#x43b;&#x435;&#x43d;&#x44c;&#x43a;&#x438;&#x435; &#x434;&#x435;&#x439;&#x441;&#x442;&#x432;&#x438;&#x44f; &#x441; &#x440;&#x430;&#x437;&#x43d;&#x44b;&#x445; &#x441;&#x442;&#x43e;&#x440;&#x43e;&#x43d;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
<node CREATED="1201790233281" MODIFIED="1201790233281" TEXT="&#x41f;&#x440;&#x43e;&#x43c;&#x435;&#x436;&#x443;&#x442;&#x43e;&#x447;&#x43d;&#x44b;&#x435; &#x440;&#x430;&#x434;&#x43e;&#x441;&#x442;&#x438;">
<icon BUILTIN="ksmiletris"/>
</node>
<node CREATED="1201790233281" FOLDED="true" ID="Freemind_Link_1434269111" MODIFIED="1201790233281" TEXT="&#x41d;&#x435;&#x43f;&#x440;&#x438;&#x44f;&#x442;&#x43d;&#x430;&#x44f; &#x437;&#x430;&#x434;&#x430;&#x447;&#x430;">
<icon BUILTIN="clanbomber"/>
<node CREATED="1201790233281" MODIFIED="1201790233281" TEXT="&#x420;&#x430;&#x437;&#x431;&#x438;&#x442;&#x44c; &#x43d;&#x430; &#x43c;&#x435;&#x43b;&#x43a;&#x438;&#x435;"/>
<node CREATED="1201790233281" FOLDED="true" ID="Freemind_Link_760842988" MODIFIED="1201790233281" TEXT="&#x421;&#x434;&#x435;&#x43b;&#x430;&#x442;&#x44c; &#x43a;&#x443;&#x441;&#x43e;&#x447;&#x435;&#x43a; ">
<node CREATED="1201790233281" FOLDED="true" ID="Freemind_Link_1651793668" MODIFIED="1201790233281" TEXT="&#x441;&#x440;&#x430;&#x437;&#x443; ">
<node CREATED="1201790233281" MODIFIED="1201790233281" TEXT="&#x443;&#x442;&#x440;&#x43e;&#x43c;"/>
</node>
</node>
</node>
<node CREATED="1201790233281" FOLDED="true" ID="Freemind_Link_1771061570" MODIFIED="1201790233281" TEXT="&#x414;&#x435;&#x43b;&#x438;&#x442;&#x44c; &#x431;&#x43e;&#x43b;&#x44c;&#x448;&#x438;&#x435; &#x43f;&#x440;&#x43e;&#x435;&#x43a;&#x442;&#x44b;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233281" MODIFIED="1201790233281" TEXT="&#x41a;&#x43d;&#x443;&#x442; &#x438; &#x41f;&#x440;&#x44f;&#x43d;&#x438;&#x43a;"/>
<node CREATED="1201790233281" FOLDED="true" ID="Freemind_Link_1930710274" MODIFIED="1201790233281" TEXT="&#x41e;&#x442;&#x43c;&#x435;&#x440;&#x44f;&#x442;&#x44c; &#x440;&#x435;&#x437;&#x443;&#x43b;&#x44c;&#x442;&#x430;&#x442;&#x44b;">
<node CREATED="1201790233281" MODIFIED="1201790233281" TEXT="&#x413;&#x440;&#x430;&#x444;&#x438;&#x43a;&#x438;">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1201790233282" FOLDED="true" ID="Freemind_Link_1004799945" MODIFIED="1201790233282" TEXT="&#x41f;&#x43e;&#x43c;&#x435;&#x441;&#x442;&#x438;&#x442;&#x44c; &#x432; &#x41c;&#x435;&#x441;&#x442;&#x43e; &#x441;&#x43c;&#x435;&#x440;&#x442;&#x438;">
<node CREATED="1201790233282" FOLDED="true" ID="Freemind_Link_40483858" MODIFIED="1201790233282" TEXT="&#x423;&#x439;&#x442;&#x438; &#x43d;&#x435;&#x43b;&#x44c;&#x437;&#x44f;">
<icon BUILTIN="bell"/>
<node CREATED="1201790233282" MODIFIED="1201790233282" TEXT="redline">
<icon BUILTIN="messagebox_warning"/>
</node>
<node CREATED="1201790233282" MODIFIED="1201790233282" TEXT="deadline">
<icon BUILTIN="flag"/>
</node>
</node>
<node CREATED="1201790233282" FOLDED="true" ID="Freemind_Link_1776991151" MODIFIED="1201790233282" TEXT="&#x418;&#x43b;&#x438;">
<node CREATED="1201790233282" MODIFIED="1201790233282" TEXT="&#x421;&#x434;&#x435;&#x43b;&#x430;&#x43b;">
<icon BUILTIN="messagebox_warning"/>
</node>
<node CREATED="1201790233282" MODIFIED="1201790233282" TEXT="&#x41f;&#x440;&#x43e;&#x432;&#x430;&#x43b;&#x438;&#x43b;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
</node>
</node>
<node CREATED="1201790233282" FOLDED="true" ID="Freemind_Link_1390497763" MODIFIED="1201790233282" TEXT="&#x422;&#x430;&#x431;&#x43b;&#x438;&#x446;&#x430; &#x435;&#x436;&#x435;&#x434;&#x43d;&#x435;&#x432;&#x43d;&#x44b;&#x445; &#x434;&#x435;&#x43b;">
<node CREATED="1201790233282" MODIFIED="1201790233282" TEXT="&#x41d;&#x430; &#x432;&#x438;&#x434;&#x43d;&#x43e;&#x435; &#x43c;&#x435;&#x441;&#x442;&#x43e;">
<icon BUILTIN="messagebox_warning"/>
</node>
<node CREATED="1201790233282" FOLDED="true" ID="Freemind_Link_74740181" MODIFIED="1201790233282" TEXT="&#x41f;&#x440;&#x43e;&#x43c;&#x435;&#x436;&#x443;&#x442;&#x43e;&#x447;&#x43d;&#x44b;&#x435;">
<node CREATED="1201790233282" MODIFIED="1201790233282" TEXT="&#x440;&#x430;&#x434;&#x43e;&#x441;&#x442;&#x438;"/>
</node>
<node CREATED="1201790233282" FOLDED="true" ID="Freemind_Link_427035492" MODIFIED="1201790233282" TEXT="&#x41d;&#x430;&#x433;&#x440;&#x430;&#x434;&#x44b;">
<node CREATED="1201790233282" MODIFIED="1201790233282" TEXT="&#x437;&#x430; &#x432;&#x44b;&#x43f;&#x43e;&#x43b;&#x43d;&#x435;&#x43d;&#x438;&#x435;"/>
</node>
</node>
<node CREATED="1201790233282" FOLDED="true" ID="Freemind_Link_1194741525" MODIFIED="1201790233282" TEXT="&#x41a;&#x430;&#x43b;&#x435;&#x43d;&#x434;&#x430;&#x440;&#x438;&#x43a;-&#x43f;&#x438;&#x43d;&#x430;&#x440;&#x438;&#x43a;">
<node CREATED="1201790233282" FOLDED="true" ID="Freemind_Link_1098031443" MODIFIED="1201790233282" TEXT="&#x412;&#x44b;&#x447;&#x435;&#x440;&#x43a;&#x438;&#x432;&#x430;&#x442;&#x44c;">
<node CREATED="1201790233282" MODIFIED="1201790233282" TEXT="&#x441;&#x432;&#x43e;&#x44e; &#x436;&#x438;&#x437;&#x43d;&#x44c;"/>
</node>
</node>
</node>
<node CREATED="1201790233283" FOLDED="true" ID="Freemind_Link_999236517" MODIFIED="1201790233283" TEXT="&#x433;&#x43b;3: &#x426;&#x435;&#x43b;&#x438;">
<node CREATED="1201790233283" FOLDED="true" ID="Freemind_Link_1134845041" MODIFIED="1201790233283" TEXT="&#x41f;&#x43e;&#x434;&#x445;&#x43e;&#x434;&#x44b; (&#x43f;&#x43e; &#x41a;&#x43e;&#x432;&#x438;)">
<node CREATED="1201790233283" FOLDED="true" ID="Freemind_Link_1934253120" MODIFIED="1201790233283" TEXT="&#x420;&#x435;&#x430;&#x43a;&#x442;&#x438;&#x432;&#x43d;&#x44b;&#x439;">
<node CREATED="1201790233283" MODIFIED="1201790233283" TEXT="&#x41a;&#x430;&#x43a; &#x43f;&#x43e;&#x43b;&#x443;&#x447;&#x438;&#x43b;&#x43e;&#x441;&#x44c;"/>
</node>
<node CREATED="1201790233283" FOLDED="true" ID="Freemind_Link_768824334" MODIFIED="1201790233283" TEXT="&#x41f;&#x440;&#x43e;&#x430;&#x43a;&#x442;&#x438;&#x432;&#x43d;&#x44b;&#x439;">
<node CREATED="1201790233283" MODIFIED="1201790233283" TEXT="&#x413;&#x43d;&#x443; &#x441;&#x432;&#x43e;&#x44e; &#x43b;&#x438;&#x43d;&#x438;&#x44e;"/>
</node>
</node>
<node CREATED="1201790233283" FOLDED="true" ID="Freemind_Link_24602044" MODIFIED="1201790233283" TEXT="&#x42f; - &#x43a;&#x43e;&#x440;&#x43f;&#x43e;&#x440;&#x430;&#x446;&#x438;&#x44f;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233283" FOLDED="true" ID="Freemind_Link_397555999" MODIFIED="1201790233283" TEXT="&#x410;&#x432;&#x442;&#x43e;&#x43d;&#x43e;&#x43c;&#x43d;&#x43e;&#x441;&#x442;&#x44c;">
<node CREATED="1201790233283" MODIFIED="1201790233283" TEXT="&#x41f;&#x430;&#x440;&#x442;&#x43d;&#x451;&#x440;&#x441;&#x442;&#x432;&#x43e;"/>
</node>
<node CREATED="1201790233283" FOLDED="true" ID="Freemind_Link_1825947651" MODIFIED="1201790233283" TEXT="&#x417;&#x430;&#x442;&#x43e;&#x447;&#x43a;&#x430; &#x43c;&#x435;&#x442;&#x43e;&#x434;&#x43e;&#x432;">
<node CREATED="1201790233283" MODIFIED="1201790233283" TEXT="&#x43f;&#x43e;&#x434; &#x441;&#x435;&#x431;&#x44f;"/>
</node>
<node CREATED="1201790233283" FOLDED="true" ID="Freemind_Link_111549295" MODIFIED="1201790233283" TEXT="&#x414;&#x435;&#x44f;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x43e;&#x441;&#x442;&#x44c;">
<node CREATED="1201790233283" FOLDED="true" ID="Freemind_Link_1637337698" MODIFIED="1201790233283" TEXT="&#x41c;&#x430;&#x440;&#x43a;&#x435;&#x442;&#x438;&#x43d;&#x433;">
<node CREATED="1201790233283" MODIFIED="1201790233283" TEXT="&#x420;&#x44b;&#x43d;&#x43e;&#x43a; &#x442;&#x440;&#x443;&#x434;&#x430;"/>
</node>
<node CREATED="1201790233283" MODIFIED="1201790233283" TEXT="&#x421;&#x442;&#x440;&#x430;&#x442;&#x435;&#x433;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x43e;&#x435; &#x43f;&#x43b;&#x430;&#x43d;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435;"/>
<node CREATED="1201790233283" MODIFIED="1201790233283" TEXT="&#x41b;&#x438;&#x447;&#x43d;&#x430;&#x44f; &#x431;&#x443;&#x445;&#x433;&#x430;&#x43b;&#x442;&#x435;&#x440;&#x438;&#x44f;"/>
</node>
</node>
<node CREATED="1201790233283" FOLDED="true" ID="Freemind_Link_1793240255" MODIFIED="1201790233283" TEXT="&#x417;&#x430;&#x43f;&#x438;&#x441;&#x430;&#x442;&#x44c;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233283" FOLDED="true" ID="Freemind_Link_1794712434" MODIFIED="1201790233283" TEXT="&#x426;&#x435;&#x43b;&#x438;">
<node CREATED="1201790233283" FOLDED="true" ID="Freemind_Link_1285722710" MODIFIED="1201790233283" TEXT="&#x42d;&#x441;&#x441;&#x435;">
<node CREATED="1201790233283" MODIFIED="1201790233283" TEXT="&#x42f; &#x447;&#x435;&#x440;&#x435;&#x437; 5 &#x43b;&#x435;&#x442;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_1370634592" MODIFIED="1201790233284" TEXT="&#x41f;&#x430;&#x440;&#x443; &#x441;&#x442;&#x440;&#x430;&#x43d;&#x438;&#x446;">
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x41f;&#x435;&#x440;&#x438;&#x43e;&#x434;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x438; &#x43f;&#x440;&#x430;&#x432;&#x438;&#x442;&#x44c;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_722879778" MODIFIED="1201790233284" TEXT="&#x41e;&#x43f;&#x440;&#x435;&#x434;&#x435;&#x43b;&#x438;&#x442;&#x44c;">
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_1489333284" MODIFIED="1201790233284" TEXT="&#x420;&#x43e;&#x434;&#x43d;&#x44b;&#x435; &#x446;&#x435;&#x43b;&#x438;">
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x41d;&#x430;&#x439;&#x442;&#x438;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_1274128157" MODIFIED="1201790233284" TEXT="&#x41d;&#x430;&#x432;&#x44f;&#x437;&#x430;&#x43d;&#x43d;&#x44b;&#x435; &#x446;&#x435;&#x43b;&#x438;">
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x41e;&#x442;&#x441;&#x435;&#x44f;&#x442;&#x44c;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
</node>
</node>
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_138341737" MODIFIED="1201790233284" TEXT="&#x411;&#x430;&#x437;&#x43e;&#x432;&#x44b;&#x435; &#x446;&#x435;&#x43d;&#x43d;&#x43e;&#x441;&#x442;&#x438;">
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_642704252" MODIFIED="1201790233284" TEXT="&#x421;&#x442;&#x430;&#x442;&#x438;&#x441;&#x442;&#x438;&#x43a;&#x430;">
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x413;&#x43b;&#x430;&#x432;&#x43d;&#x43e;&#x435; &#x441;&#x43e;&#x431;&#x44b;&#x442;&#x438;&#x435; &#x434;&#x43d;&#x44f;"/>
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x413;&#x43b;&#x430;&#x432;&#x43d;&#x43e;&#x435; &#x441;&#x43e;&#x431;&#x44b;&#x442;&#x438;&#x435; &#x43d;&#x435;&#x434;&#x435;&#x43b;&#x438;"/>
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x413;&#x43b;&#x430;&#x432;&#x43d;&#x43e;&#x435; &#x441;&#x43e;&#x431;&#x44b;&#x442;&#x438;&#x435; &#x43c;&#x435;&#x441;&#x44f;&#x446;&#x430;"/>
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x413;&#x43b;&#x430;&#x432;&#x43d;&#x43e;&#x435; &#x441;&#x43e;&#x431;&#x44b;&#x442;&#x438;&#x435; &#x433;&#x43e;&#x434;&#x430;"/>
</node>
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_1962892176" MODIFIED="1201790233284" TEXT="&#x41f;&#x43e;&#x447;&#x435;&#x43c;&#x443; &#x44d;&#x442;&#x43e;?">
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x420;&#x44f;&#x434;&#x43e;&#x43c; &#x43d;&#x430;&#x437;&#x432;&#x430;&#x442;&#x44c; &#x446;&#x435;&#x43d;&#x43d;&#x43e;&#x441;&#x442;&#x44c;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
</node>
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_749434691" MODIFIED="1201790233284" TEXT="&#x41b;&#x438;&#x447;&#x43d;&#x430;&#x44f; &#x43c;&#x438;&#x441;&#x441;&#x438;&#x44f;">
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_1945698988" MODIFIED="1201790233284" TEXT="&#x426;&#x435;&#x43b;&#x438; - &#x442;&#x43e;, &#x447;&#x442;&#x43e; &#x445;&#x43e;&#x442;&#x438;&#x43c; &#x43f;&#x43e;&#x43b;&#x443;&#x447;&#x438;&#x442;&#x44c; &#x43e;&#x442; &#x43c;&#x438;&#x440;&#x430;">
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x41c;&#x438;&#x441;&#x441;&#x438;&#x44f; - &#x442;&#x43e;, &#x447;&#x442;&#x43e; &#x445;&#x43e;&#x442;&#x438;&#x43c; &#x43f;&#x440;&#x438;&#x43d;&#x435;&#x441;&#x442;&#x438; &#x432; &#x43c;&#x438;&#x440;"/>
</node>
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_607452199" MODIFIED="1201790233284" TEXT="&#x44d;&#x442;&#x43e; &#x43d;&#x430;&#x448;&#x430; &#x43b;&#x438;&#x447;&#x43d;&#x430;&#x44f; &#x443;&#x43d;&#x438;&#x43a;&#x430;&#x43b;&#x44c;&#x43d;&#x43e;&#x441;&#x442;&#x44c;">
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x422;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x44f;"/>
</node>
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_733614338" MODIFIED="1201790233284" TEXT="&#x41d;&#x430;&#x434;&#x43f;&#x438;&#x441;&#x44c; &#x43d;&#x430; &#x43d;&#x430;&#x434;&#x433;&#x440;&#x43e;&#x431;&#x43d;&#x43e;&#x43c; &#x43a;&#x430;&#x43c;&#x43d;&#x435;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x412;&#x44b;&#x43a;&#x440;&#x438;&#x441;&#x442;&#x430;&#x43b;&#x43b;&#x438;&#x437;&#x43e;&#x432;&#x44b;&#x432;&#x430;&#x442;&#x44c; &#x441;&#x43e; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x435;&#x43c;"/>
</node>
</node>
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_1082469409" MODIFIED="1201790233284" TEXT="&#x41f;&#x440;&#x438;&#x437;&#x432;&#x430;&#x43d;&#x438;&#x435;">
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x41d;&#x435;&#x43b;&#x44c;&#x437;&#x44f; &#x443;&#x436;&#x435; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x438;&#x442;&#x44c;"/>
<node CREATED="1201790233284" FOLDED="true" ID="Freemind_Link_1043138106" MODIFIED="1201790233284" TEXT="&#x412;&#x43d;&#x443;&#x442;&#x440;&#x435;&#x43d;&#x43d;&#x435;&#x435;">
<node CREATED="1201790233284" MODIFIED="1201790233284" TEXT="&#x43a; &#x43e;&#x43f;&#x440;&#x435;&#x434;&#x435;&#x43b;&#x451;&#x43d;&#x43d;&#x43e;&#x43c;&#x443; &#x434;&#x435;&#x43b;&#x443;"/>
</node>
</node>
</node>
<node CREATED="1201790233285" FOLDED="true" ID="Freemind_Link_184173579" MODIFIED="1201790233285" TEXT="&#x41a;&#x43b;&#x44e;&#x447;&#x435;&#x432;&#x44b;&#x435; &#x43e;&#x431;&#x43b;&#x430;&#x441;&#x442;&#x438; &#x436;&#x438;&#x437;&#x43d;&#x438;">
<node CREATED="1201790233285" FOLDED="true" ID="Freemind_Link_111736057" MODIFIED="1201790233285" TEXT="5-9 &#x43d;&#x430;&#x43f;&#x440;&#x430;&#x432;&#x43b;&#x435;&#x43d;&#x438;&#x439;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x41e;&#x431;&#x440;&#x430;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435;/&#x420;&#x430;&#x437;&#x432;&#x438;&#x442;&#x438;&#x435;/&#x423;&#x447;&#x435;&#x431;&#x430;"/>
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x421;&#x435;&#x43c;&#x44c;&#x44f;/&#x414;&#x435;&#x442;&#x438;/&#x420;&#x43e;&#x434;&#x441;&#x442;&#x432;&#x435;&#x43d;&#x43d;&#x438;&#x43a;&#x438;"/>
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x414;&#x440;&#x443;&#x437;&#x44c;&#x44f;/&#x417;&#x43d;&#x430;&#x43a;&#x43e;&#x43c;&#x44b;&#x435;/&#x41e;&#x431;&#x449;&#x435;&#x441;&#x442;&#x432;&#x43e;"/>
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x425;&#x43e;&#x431;&#x431;&#x438;/&#x423;&#x432;&#x43b;&#x435;&#x447;&#x435;&#x43d;&#x438;&#x435;"/>
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x420;&#x430;&#x431;&#x43e;&#x442;&#x430;/&#x411;&#x438;&#x437;&#x43d;&#x435;&#x441;/&#x41f;&#x440;&#x43e;&#x435;&#x43a;&#x442;&#x44b;"/>
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x421;&#x43f;&#x43e;&#x440;&#x442;/&#x417;&#x434;&#x43e;&#x440;&#x43e;&#x432;&#x44c;&#x435;"/>
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x411;&#x43b;&#x430;&#x433;&#x43e;&#x441;&#x43e;&#x441;&#x442;&#x43e;&#x44f;&#x43d;&#x438;&#x435;/&#x41a;&#x430;&#x440;&#x44c;&#x435;&#x440;&#x430;"/>
</node>
<node CREATED="1201790233285" FOLDED="true" ID="Freemind_Link_999122723" MODIFIED="1201790233285" TEXT="&#x41a;&#x430;&#x440;&#x442;&#x430; &#x434;&#x43e;&#x43b;&#x433;&#x43e;&#x441;&#x440;&#x43e;&#x447;&#x43d;&#x44b;&#x445; &#x446;&#x435;&#x43b;&#x435;&#x439;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233285" FOLDED="true" ID="Freemind_Link_1726253275" MODIFIED="1201790233285" TEXT="&#x413;&#x43e;&#x440;&#x438;&#x437;&#x43e;&#x43d;&#x442;&#x430;&#x43b;&#x44c;">
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x414;&#x430;&#x442;&#x44b;"/>
</node>
<node CREATED="1201790233285" FOLDED="true" ID="Freemind_Link_1613303125" MODIFIED="1201790233285" TEXT="&#x412;&#x435;&#x440;&#x442;&#x438;&#x43a;&#x430;&#x43b;&#x44c;">
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x41e;&#x431;&#x43b;&#x430;&#x441;&#x442;&#x438;"/>
</node>
<node CREATED="1201790233285" FOLDED="true" ID="Freemind_Link_1852517541" MODIFIED="1201790233285" TEXT="&#x41f;&#x435;&#x440;&#x435;&#x441;&#x435;&#x447;&#x435;&#x43d;&#x438;&#x435;">
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x426;&#x435;&#x43b;&#x435;&#x432;&#x44b;&#x435; &#x43e;&#x440;&#x438;&#x435;&#x43d;&#x442;&#x438;&#x440;&#x44b;"/>
</node>
</node>
</node>
<node CREATED="1201790233285" FOLDED="true" ID="Freemind_Link_64746228" MODIFIED="1201790233285" TEXT="&#x411;&#x43b;&#x438;&#x436;&#x430;&#x439;&#x448;&#x438;&#x435; &#x446;&#x435;&#x43b;&#x438;">
<node CREATED="1201790233285" FOLDED="true" ID="Freemind_Link_578402693" MODIFIED="1201790233285" STYLE="bubble" TEXT="SMART">
<node CREATED="1201790233285" FOLDED="true" ID="Freemind_Link_1037609110" MODIFIED="1201790233285" TEXT="Specific">
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x41a;&#x43e;&#x43d;&#x43a;&#x440;&#x435;&#x442;&#x43d;&#x44b;&#x435;"/>
</node>
<node CREATED="1201790233285" FOLDED="true" ID="Freemind_Link_1656793378" MODIFIED="1201790233285" TEXT="Measurable">
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x418;&#x437;&#x43c;&#x435;&#x440;&#x438;&#x43c;&#x44b;&#x435;"/>
</node>
<node CREATED="1201790233285" FOLDED="true" ID="Freemind_Link_914942733" MODIFIED="1201790233285" TEXT="Achievable">
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x414;&#x43e;&#x441;&#x442;&#x438;&#x436;&#x438;&#x43c;&#x44b;&#x435;"/>
</node>
<node CREATED="1201790233285" FOLDED="true" ID="Freemind_Link_1279903675" MODIFIED="1201790233285" TEXT="Realistic">
<node CREATED="1201790233285" MODIFIED="1201790233285" TEXT="&#x420;&#x435;&#x430;&#x43b;&#x438;&#x441;&#x442;&#x438;&#x447;&#x43d;&#x44b;&#x435;"/>
</node>
<node CREATED="1201790233286" FOLDED="true" ID="Freemind_Link_44582656" MODIFIED="1201790233286" TEXT="Time-bound">
<node CREATED="1201790233286" MODIFIED="1201790233286" TEXT="&#x41f;&#x440;&#x438;&#x432;&#x44f;&#x437;&#x430;&#x43d;&#x43d;&#x44b;&#x435; &#x43a;&#x43e; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;"/>
</node>
</node>
<node CREATED="1201790233286" MODIFIED="1201790233286" TEXT="&#x42d;&#x442;&#x43e; &#x43c;&#x430;&#x44f;&#x43a;&#x438;">
<icon BUILTIN="flag"/>
</node>
</node>
</node>
</node>
<node CREATED="1201790233286" ID="Freemind_Link_292563756" MODIFIED="1201790233286" POSITION="right" TEXT="&#x418;&#x43d;&#x441;&#x442;&#x440;&#x443;&#x43c;&#x435;&#x43d;&#x442;&#x44b; 1">
<node CREATED="1201790233286" FOLDED="true" ID="Freemind_Link_291250426" MODIFIED="1201790233286" TEXT="&#x433;&#x43b;4: &#x420;&#x430;&#x431;&#x43e;&#x447;&#x438;&#x439; &#x434;&#x435;&#x43d;&#x44c;">
<node CREATED="1201790233286" FOLDED="true" ID="Freemind_Link_1503062215" MODIFIED="1201790233286" TEXT="&#x41f;&#x43b;&#x430;&#x43d; &#x43d;&#x430; &#x434;&#x435;&#x43d;&#x44c;">
<node CREATED="1201790233286" FOLDED="true" ID="Freemind_Link_173011984" MODIFIED="1201790233286" TEXT="&#x432; &#x43e;&#x434;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x441;&#x442;&#x435;">
<node CREATED="1201790233286" MODIFIED="1201790233286" TEXT="&#x43c;&#x430;&#x442;&#x435;&#x440;&#x438;&#x430;&#x43b;&#x44c;&#x43d;&#x44b;&#x439;"/>
</node>
<node CREATED="1201790233286" FOLDED="true" ID="Freemind_Link_498973490" MODIFIED="1201790233286" TEXT="&#x43f;&#x440;&#x43e;&#x441;&#x43c;&#x430;&#x442;&#x440;&#x438;&#x432;&#x430;&#x442;&#x44c;">
<node CREATED="1201790233286" MODIFIED="1201790233286" TEXT="&#x43c;&#x435;&#x43d;&#x44f;&#x442;&#x44c; &#x43f;&#x43e; &#x43e;&#x431;&#x441;&#x442;&#x43e;&#x44f;&#x442;&#x435;&#x43b;&#x44c;&#x441;&#x442;&#x432;&#x430;&#x43c;">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1201790233286" FOLDED="true" ID="Freemind_Link_106021695" MODIFIED="1201790233286" TEXT="&#x43f;&#x43b;&#x430;&#x43d;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; ">
<node CREATED="1201790233286" MODIFIED="1201790233286" TEXT="&#x441; &#x443;&#x442;&#x440;&#x430;"/>
<node CREATED="1201790233286" MODIFIED="1201790233286" TEXT="&#x441; &#x432;&#x435;&#x447;&#x435;&#x440;&#x430;"/>
</node>
</node>
<node CREATED="1201790233286" FOLDED="true" ID="Freemind_Link_1535678209" MODIFIED="1201790233286" TEXT="&#x415;&#x436;&#x435;&#x434;&#x43d;&#x435;&#x432;&#x43d;&#x438;&#x43a;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233286" FOLDED="true" ID="Freemind_Link_47782893" MODIFIED="1201790233286" TEXT="&#x41e;&#x431;&#x437;&#x43e;&#x440;">
<node CREATED="1201790233286" MODIFIED="1201790233286" TEXT="&#x43d;&#x435;&#x434;&#x435;&#x43b;&#x438;"/>
<node CREATED="1201790233286" MODIFIED="1201790233286" TEXT="&#x434;&#x43d;&#x44f;"/>
</node>
<node CREATED="1201790233286" MODIFIED="1201790233286" TEXT="&#x421;&#x442;&#x438;&#x43a;&#x435;&#x440;&#x44b;"/>
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x420;&#x430;&#x437;&#x43d;&#x44b;&#x439; &#x446;&#x432;&#x435;&#x442;"/>
<node CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_697284698" MODIFIED="1201790233287" TEXT="&#x417;&#x430;&#x43a;&#x43b;&#x430;&#x434;&#x43a;&#x430;">
<icon BUILTIN="ksmiletris"/>
<node CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_84070623" MODIFIED="1201790233287" TEXT="&#x430;&#x43a;&#x442;&#x443;&#x430;&#x43b;&#x44c;&#x43d;&#x44b;&#x435;">
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x437;&#x430;&#x434;&#x430;&#x447;&#x438;">
<icon BUILTIN="messagebox_warning"/>
</node>
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x43a;&#x43e;&#x43d;&#x442;&#x430;&#x43a;&#x442;&#x44b;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x442;&#x435;&#x43c;&#x44b; &#x434;&#x43b;&#x44f; &#x440;&#x430;&#x437;&#x43c;&#x44b;&#x448;&#x43b;&#x435;&#x43d;&#x438;&#x44f;">
<icon BUILTIN="messagebox_warning"/>
</node>
<node CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_1623793152" MODIFIED="1201790233287" TEXT="&#x441;&#x442;&#x440;&#x430;&#x442;&#x435;&#x433;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x430;&#x44f; &#x43a;&#x430;&#x440;&#x442;&#x43e;&#x43d;&#x43a;&#x430;">
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x434;&#x43e;&#x43b;&#x433;&#x43e;&#x441;&#x440;&#x43e;&#x447;&#x43d;&#x44b;&#x435; &#x446;&#x435;&#x43b;&#x438;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
</node>
</node>
<node CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_137028731" MODIFIED="1201790233287" TEXT="&#x410;&#x43b;&#x433;&#x43e;&#x440;&#x438;&#x442;&#x43c;">
<icon BUILTIN="forward"/>
<node CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_1400495273" MODIFIED="1201790233287" TEXT="&#x422;&#x438;&#x43f;&#x44b; &#x437;&#x430;&#x434;&#x430;&#x447;">
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x444;&#x438;&#x43a;&#x441;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x43d;&#x44b;&#x435; &#x432;&#x441;&#x442;&#x440;&#x435;&#x447;&#x438;"/>
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x43f;&#x43b;&#x430;&#x432;&#x430;&#x44e;&#x449;&#x438;&#x435;"/>
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x43a;&#x440;&#x443;&#x43f;&#x43d;&#x44b;&#x435; (&#x43c;&#x43d;&#x43e;&#x433;&#x43e; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;)"/>
</node>
<node CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_1171236738" MODIFIED="1201790233287" TEXT="&#x41f;&#x43e;&#x440;&#x44f;&#x434;&#x43e;&#x43a;">
<node CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_1166676581" MODIFIED="1201790233287" TEXT="&#x43f;&#x43e;&#x43b;&#x43d;&#x44b;&#x439; &#x441;&#x43f;&#x438;&#x441;&#x43e;&#x43a; &#x433;&#x438;&#x431;&#x43a;&#x438;&#x445;">
<node COLOR="#808080" CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_140223629" MODIFIED="1201790233287" TEXT="&#x424;&#x43e;&#x440;&#x43c;&#x443;&#x43b;&#x438;&#x440;&#x43e;&#x432;&#x43a;&#x438;">
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x420;&#x435;&#x437;&#x443;&#x43b;&#x44c;&#x442;&#x430;&#x442;&#x43e;&#x43e;&#x440;&#x438;&#x435;&#x43d;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x44b;&#x435;"/>
</node>
</node>
<node CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_1775497595" MODIFIED="1201790233287" TEXT="&#x43a;&#x440;&#x430;&#x441;&#x43d;&#x44b;&#x43c; 2-3 &#x43f;&#x440;&#x438;&#x43e;&#x440;&#x438;&#x442;&#x435;&#x442;&#x43d;&#x44b;&#x445;">
<node COLOR="#808080" CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_1633437017" MODIFIED="1201790233287" TEXT="&#x41f;&#x440;&#x438;&#x43e;&#x440;&#x438;&#x442;&#x435;&#x442;&#x44b;">
<node CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_1570622554" MODIFIED="1201790233287" TEXT="&#x423;&#x442;&#x43e;&#x447;&#x43d;&#x44f;&#x44e;&#x449;&#x438;&#x435;">
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x414;&#x435;&#x43b;&#x435;&#x433;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435;"/>
</node>
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x421;&#x440;&#x43e;&#x447;&#x43d;&#x44b;&#x435;  (&#x431;&#x435;&#x437;&#x43e;&#x442;&#x43b;&#x430;&#x433;&#x430;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x44b;&#x435;)"/>
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x41e;&#x441;&#x442;&#x430;&#x43b;&#x44c;&#x43d;&#x44b;&#x435;"/>
</node>
</node>
<node CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_600977662" MODIFIED="1201790233287" TEXT="&#x432;&#x43f;&#x438;&#x441;&#x430;&#x442;&#x44c; &#x444;&#x438;&#x43a;&#x441;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x43d;&#x44b;&#x435; &#x432;&#x441;&#x442;&#x440;&#x435;&#x447;&#x438;">
<node COLOR="#808080" CREATED="1201790233287" FOLDED="true" ID="Freemind_Link_1098955203" MODIFIED="1201790233287" TEXT="&#x420;&#x435;&#x437;&#x435;&#x440;&#x432; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;">
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x43d;&#x430; &#x434;&#x43e;&#x440;&#x43e;&#x433;&#x443;"/>
<node CREATED="1201790233287" MODIFIED="1201790233287" TEXT="&#x432;&#x441;&#x43f;&#x43e;&#x43c;&#x43e;&#x433;&#x430;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x44b;&#x435; &#x434;&#x435;&#x43b;&#x430;"/>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x43e;&#x440;&#x433;&#x430;&#x43d;&#x438;&#x437;&#x430;&#x446;&#x438;&#x43e;&#x43d;&#x43d;&#x44b;&#x435; &#x43d;&#x435;&#x441;&#x442;&#x44b;&#x43a;&#x43e;&#x432;&#x43a;&#x438;"/>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x43f;&#x43e;&#x441;&#x442;: &#x437;&#x435;&#x43b;&#x451;&#x43d;&#x430;&#x44f; &#x437;&#x43e;&#x43d;&#x430;"/>
</node>
<node COLOR="#808080" CREATED="1201790233288" FOLDED="true" ID="Freemind_Link_1016903620" MODIFIED="1201790233288" TEXT="&#x41e;&#x433;&#x43e;&#x432;&#x43e;&#x440;&#x438;&#x442;&#x44c; &#x442;&#x43e;&#x447;&#x43d;&#x43e;&#x441;&#x442;&#x44c;">
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x41f;&#x443;&#x43d;&#x43a;&#x442;&#x443;&#x430;&#x43b;&#x44c;&#x43d;&#x43e;&#x441;&#x442;&#x44c;"/>
</node>
</node>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x434;&#x43b;&#x44f; &#x432;&#x430;&#x436;&#x43d;&#x44b;&#x445; &#x43a;&#x440;&#x443;&#x43f;&#x43d;&#x44b;&#x445; &#x432;&#x44b;&#x434;&#x435;&#x43b;&#x438;&#x442;&#x44c; &#x432;&#x440;&#x435;&#x43c;&#x44f;"/>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x43e;&#x441;&#x442;&#x430;&#x43b;&#x44c;&#x43d;&#x43e;&#x435; &#x437;&#x430;&#x43f;&#x43e;&#x43b;&#x43d;&#x44f;&#x442;&#x44c; &#x43f;&#x43e; &#x445;&#x43e;&#x434;&#x443;, &#x43d;&#x430;&#x447;&#x438;&#x43d;&#x430;&#x44f; &#x441; &#x43a;&#x440;&#x430;&#x441;&#x43d;&#x44b;&#x445;"/>
</node>
</node>
<node CREATED="1201790233288" FOLDED="true" ID="Freemind_Link_1968542407" MODIFIED="1201790233288" TEXT="&#x418;&#x43d;&#x444;&#x43e;&#x440;&#x43c;&#x430;&#x446;&#x438;&#x43e;&#x43d;&#x43d;&#x430;&#x44f; &#x438;&#x437;&#x431;&#x44b;&#x442;&#x43e;&#x447;&#x43d;&#x43e;&#x441;&#x442;&#x44c;">
<icon BUILTIN="ksmiletris"/>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x43f;&#x43e;&#x434;&#x442;&#x432;&#x435;&#x440;&#x436;&#x434;&#x435;&#x43d;&#x438;&#x435; &#x432;&#x441;&#x442;&#x440;&#x435;&#x447;"/>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x43f;&#x435;&#x440;&#x435;&#x441;&#x442;&#x440;&#x430;&#x445;&#x43e;&#x432;&#x43a;&#x438;"/>
<node CREATED="1201790233288" FOLDED="true" ID="Freemind_Link_681314285" MODIFIED="1201790233288" TEXT="&#x432;&#x441;&#x442;&#x440;&#x435;&#x447;&#x430;">
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x441;&#x445;&#x435;&#x43c;&#x430; &#x43f;&#x440;&#x43e;&#x435;&#x437;&#x434;&#x430;"/>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x43c;&#x430;&#x43a;&#x441;&#x438;&#x43c;&#x430;&#x43b;&#x44c;&#x43d;&#x43e;&#x435; &#x432;&#x440;&#x435;&#x43c;&#x44f; &#x43d;&#x430; &#x434;&#x43e;&#x440;&#x43e;&#x433;&#x443;"/>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x432;&#x441;&#x435; &#x43d;&#x43e;&#x43c;&#x435;&#x440;&#x430; &#x442;&#x435;&#x43b;&#x435;&#x444;&#x43e;&#x43d;&#x43e;&#x432;"/>
<node CREATED="1201790233288" FOLDED="true" ID="Freemind_Link_693972664" MODIFIED="1201790233288" TEXT="&#x43f;&#x440;&#x43e;&#x432;&#x435;&#x440;&#x438;&#x442;&#x44c; &#x430;&#x434;&#x440;&#x435;&#x441;">
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x43a;&#x43e;&#x440;&#x43f;&#x443;&#x441;"/>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x433;&#x434;&#x435; &#x43e;&#x444;&#x438;&#x441;"/>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x43f;&#x440;&#x43e;&#x43f;&#x443;&#x441;&#x43a;&#x43d;&#x43e;&#x439; &#x440;&#x435;&#x436;&#x438;&#x43c;"/>
</node>
</node>
</node>
</node>
<node CREATED="1201790233288" FOLDED="true" ID="Freemind_Link_1463863079" MODIFIED="1201790233288" TEXT="&#x433;&#x43b;5: &#x41f;&#x43b;&#x430;&#x43d;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435;">
<node CREATED="1201790233288" FOLDED="true" ID="Freemind_Link_339446177" MODIFIED="1201790233288" TEXT="&#x412;&#x440;&#x435;&#x43c;&#x44f;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233288" FOLDED="true" ID="Freemind_Link_111637283" MODIFIED="1201790233288" TEXT="&#x425;&#x440;&#x43e;&#x43d;&#x43e;&#x441;">
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x43b;&#x438;&#x43d;&#x435;&#x439;&#x43d;&#x43e;&#x435;"/>
</node>
<node CREATED="1201790233288" FOLDED="true" ID="Freemind_Link_413223510" MODIFIED="1201790233288" TEXT="&#x41a;&#x430;&#x439;&#x440;&#x43e;&#x441;">
<icon BUILTIN="button_ok"/>
<node CREATED="1201790233288" FOLDED="true" ID="Freemind_Link_563961330" MODIFIED="1201790233288" TEXT="&#x43c;&#x43e;&#x43c;&#x435;&#x43d;&#x442;&#x43e;&#x43e;&#x440;&#x438;&#x435;&#x43d;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x43e;&#x435;">
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x41c;&#x435;&#x441;&#x442;&#x43e;">
<icon BUILTIN="flag"/>
</node>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x427;&#x435;&#x43b;&#x43e;&#x432;&#x435;&#x43a;/&#x413;&#x440;&#x443;&#x43f;&#x43f;&#x430;">
<icon BUILTIN="messagebox_warning"/>
</node>
<node CREATED="1201790233288" FOLDED="true" ID="Freemind_Link_487868637" MODIFIED="1201790233288" TEXT="&#x412;&#x43d;&#x443;&#x442;&#x440;&#x435;&#x43d;&#x43d;&#x438;&#x435; &#x43e;&#x431;&#x441;&#x442;&#x43e;&#x44f;&#x442;&#x435;&#x43b;&#x44c;&#x441;&#x442;&#x432;&#x430;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x412;&#x434;&#x43e;&#x445;&#x43d;&#x43e;&#x432;&#x435;&#x43d;&#x438;&#x435;"/>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x425;&#x43e;&#x442;&#x435;&#x43d;&#x438;&#x435;"/>
<node CREATED="1201790233288" MODIFIED="1201790233288" TEXT="&#x41d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x435;&#x43d;&#x438;&#x44f;"/>
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x423;&#x441;&#x442;&#x430;&#x43b;&#x43e;&#x441;&#x442;&#x44c;"/>
</node>
<node CREATED="1201790233289" FOLDED="true" ID="Freemind_Link_1452268606" MODIFIED="1201790233289" TEXT="&#x412;&#x43d;&#x435;&#x448;&#x43d;&#x438;&#x435; &#x43e;&#x431;&#x441;&#x442;&#x43e;&#x44f;&#x442;&#x435;&#x43b;&#x44c;&#x441;&#x442;&#x432;&#x430;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x411;&#x443;&#x434;&#x435;&#x442; &#x448;&#x435;&#x444;"/>
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x41f;&#x440;&#x438;&#x43c;&#x443;&#x442; &#x437;&#x430;&#x43a;&#x43e;&#x43d;"/>
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x41f;&#x43e;&#x44f;&#x432;&#x438;&#x442;&#x44c;&#x441;&#x44f; &#x432; &#x43f;&#x440;&#x43e;&#x434;&#x430;&#x436;&#x435;"/>
</node>
</node>
<node CREATED="1201790233289" FOLDED="true" ID="Freemind_Link_1506768699" MODIFIED="1201790233289" TEXT="&#x418;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c;">
<node CREATED="1201790233289" FOLDED="true" ID="Freemind_Link_535441757" MODIFIED="1201790233289" TEXT="&#x415;&#x436;&#x435;&#x434;&#x43d;&#x435;&#x432;&#x43d;&#x438;&#x43a;">
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x420;&#x430;&#x437;&#x434;&#x435;&#x43b;&#x44b;"/>
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x421;&#x442;&#x438;&#x43a;&#x435;&#x440;&#x44b;"/>
</node>
<node CREATED="1201790233289" FOLDED="true" ID="Freemind_Link_298457453" MODIFIED="1201790233289" TEXT="&#x41f;&#x418;&#x41c;">
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x41a;&#x430;&#x442;&#x435;&#x433;&#x43e;&#x440;&#x438;&#x438;"/>
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x41d;&#x435;&#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e;"/>
</node>
</node>
</node>
</node>
<node CREATED="1201790233289" FOLDED="true" ID="Freemind_Link_1746493075" MODIFIED="1201790233289" TEXT="&#x414;&#x435;&#x43d;&#x44c;-&#x41d;&#x435;&#x434;&#x435;&#x43b;&#x44f;-&#x413;&#x43e;&#x434;">
<icon BUILTIN="bell"/>
<node CREATED="1201790233289" FOLDED="true" ID="Freemind_Link_196414066" MODIFIED="1201790233289" TEXT="&#x41f;&#x440;&#x430;&#x432;&#x438;&#x43b;&#x430; &#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x435;&#x43d;&#x438;&#x44f;">
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x41d;&#x435;&#x434;&#x435;&#x43b;&#x44f; &#x432; &#x414;&#x435;&#x43d;&#x44c;"/>
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x413;&#x43e;&#x434; &#x432; &#x41d;&#x435;&#x434;&#x435;&#x43b;&#x44f;"/>
</node>
</node>
<node CREATED="1201790233289" FOLDED="true" ID="Freemind_Link_1444636079" MODIFIED="1201790233289" TEXT="&#x414;&#x43e;&#x441;&#x43a;&#x430; &#x43f;&#x43b;&#x430;&#x43d;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f;">
<icon BUILTIN="button_ok"/>
<node CREATED="1201790233289" FOLDED="true" ID="Freemind_Link_1237495539" MODIFIED="1201790233289" TEXT="&#x422;&#x430;&#x431;&#x43b;&#x438;&#x446;&#x430;: &#x43b;&#x44e;&#x434;&#x438; &#x438; &#x43f;&#x440;&#x43e;&#x435;&#x43a;&#x442;&#x44b;">
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x43f;&#x435;&#x440;&#x435;&#x441;&#x435;&#x447;&#x435;&#x43d;&#x438;&#x435;: &#x437;&#x430;&#x434;&#x430;&#x447;&#x438;"/>
</node>
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x421;&#x442;&#x43e;&#x43b;&#x431;&#x446;&#x44b;: &#x43c;&#x435;&#x441;&#x442;&#x430;"/>
<node CREATED="1201790233289" FOLDED="true" ID="Freemind_Link_1450308248" MODIFIED="1201790233289" TEXT="&#x422;&#x430;&#x431;&#x43b;&#x438;&#x446;&#x430;: &#x414;-&#x41d;-&#x413; &#x438; &#x43b;&#x44e;&#x434;&#x438;">
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x432;&#x43c;&#x435;&#x441;&#x442;&#x43e; &#x413;&#x43e;&#x434; &#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x41c;&#x435;&#x441;&#x44f;&#x446;"/>
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x43f;&#x435;&#x440;&#x435;&#x441;&#x435;&#x447;&#x435;&#x43d;&#x438;&#x435;: &#x417;&#x430;&#x434;&#x430;&#x447;&#x438;"/>
</node>
<node CREATED="1201790233289" FOLDED="true" ID="Freemind_Link_1817192255" MODIFIED="1201790233289" TEXT="&#x421;&#x43b;&#x43e;&#x436;&#x43d;&#x430;&#x44f; &#x437;&#x430;&#x434;&#x430;&#x447;&#x430;">
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x43f;&#x43e;&#x434;&#x435;&#x43b;&#x438;&#x442;&#x44c;"/>
<node CREATED="1201790233289" FOLDED="true" ID="Freemind_Link_361505359" MODIFIED="1201790233289" TEXT="&#x421;&#x442;&#x43e;&#x43b;&#x431;&#x446;&#x44b;">
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x417;&#x430;&#x434;&#x430;&#x447;&#x438;"/>
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x418;&#x441;&#x43f;&#x43e;&#x43b;&#x43d;&#x438;&#x442;&#x435;&#x43b;&#x44c;"/>
<node CREATED="1201790233289" MODIFIED="1201790233289" TEXT="&#x414;&#x430;&#x442;&#x44b;"/>
</node>
<node CREATED="1201790233290" FOLDED="true" ID="Freemind_Link_549398749" MODIFIED="1201790233290" TEXT="&#x421;&#x442;&#x440;&#x43e;&#x43a;&#x438;">
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x41f;&#x43e;&#x434;&#x437;&#x430;&#x434;&#x430;&#x447;&#x438;"/>
</node>
</node>
<node CREATED="1201790233290" FOLDED="true" ID="Freemind_Link_411102963" MODIFIED="1201790233290" TEXT="&#x420;&#x443;&#x442;&#x438;&#x43d;&#x43d;&#x44b;&#x435; &#x434;&#x435;&#x43b;&#x430;">
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x441;&#x442;&#x440;&#x43e;&#x43a;&#x438;: &#x417;&#x430;&#x434;&#x430;&#x447;&#x430;"/>
<node CREATED="1201790233290" FOLDED="true" ID="Freemind_Link_730691632" MODIFIED="1201790233290" TEXT="&#x441;&#x442;&#x43e;&#x43b;&#x431;&#x446;&#x44b;: &#x414;&#x430;&#x442;&#x430;">
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x43d;&#x435;&#x434;&#x435;&#x43b;&#x44f;&#x43c;&#x438;"/>
</node>
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x43f;&#x435;&#x440;&#x435;&#x441;&#x435;&#x447;&#x435;&#x43d;&#x438;&#x435;: &#x413;&#x430;&#x43b;&#x43e;&#x447;&#x43a;&#x430; &#x438;&#x43b;&#x438; &#x41f;&#x440;&#x43e;&#x447;&#x435;&#x440;&#x43a;"/>
</node>
</node>
<node CREATED="1201790233290" FOLDED="true" ID="Freemind_Link_178890700" MODIFIED="1201790233290" TEXT="&#x417;&#x430;&#x442;&#x440;&#x430;&#x442;&#x44b; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;&#xa;(&#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x432; Excel)">
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x41e;&#x431;&#x449;&#x438;&#x439; &#x43e;&#x431;&#x44a;&#x435;&#x43c;"/>
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x41f;&#x440;&#x43e;&#x438;&#x437;&#x432;&#x43e;&#x434;&#x438;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x43e;&#x441;&#x442;&#x44c; &#x442;&#x440;&#x443;&#x434;&#x430;"/>
<node CREATED="1201790233290" FOLDED="true" ID="Freemind_Link_670810824" MODIFIED="1201790233290" TEXT="&#x421;&#x440;&#x43e;&#x43a;&#x438; &#x438; &#x43a;&#x43e;&#x43b;&#x438;&#x447;&#x435;&#x441;&#x442;&#x432;&#x43e; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;">
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x432;&#x44b;&#x434;&#x435;&#x43b;&#x44f;&#x44e; N &#x447;&#x430;&#x441;&#x43e;&#x432; &#x432; &#x434;&#x435;&#x43d;&#x44c;">
<icon BUILTIN="forward"/>
</node>
</node>
</node>
</node>
<node CREATED="1201790233290" FOLDED="true" ID="Freemind_Link_111080999" MODIFIED="1201790233290" TEXT="&#x433;&#x43b;6: &#x41f;&#x440;&#x438;&#x43e;&#x440;&#x438;&#x442;&#x435;&#x442;&#x44b;">
<node CREATED="1201790233290" FOLDED="true" ID="Freemind_Link_1207776112" MODIFIED="1201790233290" TEXT="&#x423;&#x431;&#x435;&#x436;&#x434;&#x435;&#x43d;&#x438;&#x44f;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x41f;&#x43e;&#x434;&#x43e;&#x436;&#x434;&#x438; &#x432;&#x44b;&#x43f;&#x43e;&#x43b;&#x43d;&#x44f;&#x442;&#x44c; - &#x43e;&#x442;&#x43c;&#x435;&#x43d;&#x44f;&#x442;">
<icon BUILTIN="messagebox_warning"/>
</node>
<node COLOR="#ff6600" CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x41e;&#x431;&#x435;&#x437;&#x44c;&#x44f;&#x43d;&#x44b; &#x43e;&#x442;&#x442;&#x44f;&#x433;&#x438;&#x432;&#x430;&#x44e;&#x442; - &#x443; &#x43d;&#x430;&#x441; &#x442;&#x430;&#x43a; &#x43f;&#x440;&#x438;&#x43d;&#x44f;&#x442;&#x43e;">
<icon BUILTIN="flag"/>
</node>
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x41d;&#x443;&#x436;&#x43d;&#x43e; &#x43b;&#x438; &#x44d;&#x442;&#x43e; &#x434;&#x435;&#x43b;&#x430;&#x442;&#x44c; &#x432;&#x43e;&#x43e;&#x431;&#x449;&#x435;?">
<icon BUILTIN="messagebox_warning"/>
</node>
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x414;&#x43e;&#x43b;&#x436;&#x435;&#x43d; &#x43b;&#x438; &#x432;&#x44b;&#x43f;&#x43e;&#x43b;&#x43d;&#x44f;&#x442;&#x44c; &#x44d;&#x442;&#x43e; &#x438;&#x43c;&#x435;&#x43d;&#x43d;&#x43e; &#x44f;?">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
<node CREATED="1201790233290" FOLDED="true" ID="Freemind_Link_383967274" MODIFIED="1201790233290" TEXT="&#x418;&#x437;&#x431;&#x430;&#x432;&#x43b;&#x435;&#x43d;&#x438;&#x435;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233290" FOLDED="true" ID="Freemind_Link_1739962256" MODIFIED="1201790233290" TEXT="&#x41e;&#x442;&#x43a;&#x430;&#x437;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233290" FOLDED="true" ID="Freemind_Link_353652432" MODIFIED="1201790233290" TEXT="&#x421;&#x43f;&#x43e;&#x441;&#x43e;&#x431;&#x44b;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x41e;&#x431;&#x43c;&#x430;&#x43d;&#x443;&#x442;&#x44c;"/>
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x41b;&#x43e;&#x433;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x438; &#x437;&#x430;&#x431;&#x43e;&#x43b;&#x442;&#x430;&#x442;&#x44c;"/>
<node CREATED="1201790233290" FOLDED="true" ID="Freemind_Link_794907424" MODIFIED="1201790233290" TEXT="&#x414;&#x430;&#x442;&#x44c; &#x43d;&#x430;&#x434;&#x435;&#x436;&#x434;&#x443;">
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x41e;&#x442;&#x43b;&#x43e;&#x436;&#x438;&#x442;&#x44c;"/>
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x417;&#x430;&#x43c;&#x43e;&#x442;&#x430;&#x442;&#x44c;"/>
</node>
<node CREATED="1201790233290" MODIFIED="1201790233290" TEXT="&#x418;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x437;&#x438;&#x442;&#x44c; &#x436;&#x435;&#x43b;&#x430;&#x435;&#x43c;&#x43e;&#x435; &#x43d;&#x435;&#x43f;&#x440;&#x438;&#x432;&#x43b;&#x435;&#x43a;&#x430;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x44b;&#x43c;"/>
<node CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x41f;&#x43e;&#x441;&#x43b;&#x430;&#x442;&#x44c; &#x43d;&#x430; &#x442;&#x440;&#x435;&#x442;&#x438;&#x439; &#x43f;&#x443;&#x442;&#x44c;"/>
</node>
<node CREATED="1201790233291" FOLDED="true" ID="Freemind_Link_1090005791" MODIFIED="1201790233291" TEXT="&#x41f;&#x440;&#x43e;&#x441;&#x442;&#x43e; &#x41d;&#x415;&#x422;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x42d;&#x442;&#x43e; &#x43c;&#x43e;&#x44f; &#x436;&#x438;&#x437;&#x43d;&#x44c;"/>
</node>
<node COLOR="#008080" CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x411;&#x438;&#x437;&#x43d;&#x435;&#x441; - &#x44d;&#x442;&#x43e; &#x434;&#x43e;&#x432;&#x435;&#x440;&#x438;&#x435;"/>
</node>
<node CREATED="1201790233291" FOLDED="true" ID="Freemind_Link_1880158813" MODIFIED="1201790233291" TEXT="&quot;&#x41f;&#x43e;&#x43a;&#x443;&#x43f;&#x43a;&#x430;&quot; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x411;&#x43e;&#x43b;&#x44c;&#x448;&#x43e;&#x439; &#x43e;&#x431;&#x44a;&#x435;&#x43c; &#x437;&#x430;&#x434;&#x430;&#x447;&#x438;"/>
<node CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x41f;&#x43e; &#x434;&#x440;&#x443;&#x433;&#x43e;&#x439; &#x43a;&#x43e;&#x43c;&#x43f;&#x435;&#x442;&#x435;&#x43d;&#x442;&#x43d;&#x43e;&#x441;&#x442;&#x438;"/>
<node CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x41e;&#x442;&#x43b;&#x438;&#x447;&#x438;&#x435; &#x441;&#x442;&#x43e;&#x438;&#x43c;&#x43e;&#x441;&#x442;&#x438; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;"/>
<node CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x421;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x442;&#x435;&#x440;&#x44f;&#x435;&#x43c;?"/>
<node CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x414;&#x43e;&#x43c;&#x440;&#x430;&#x431;&#x43e;&#x442;&#x43d;&#x438;&#x446;&#x443;"/>
</node>
<node CREATED="1201790233291" FOLDED="true" ID="Freemind_Link_1463038053" MODIFIED="1201790233291" TEXT="&#x414;&#x435;&#x43b;&#x435;&#x433;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233291" FOLDED="true" ID="Freemind_Link_1914383702" MODIFIED="1201790233291" TEXT="&#x417;&#x430;&#x434;&#x430;&#x447;&#x443; &#x43e;&#x442;&#x434;&#x430;&#x432;&#x430;&#x442;&#x44c;">
<node CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x430;&#x43a;&#x442;&#x438;&#x432;&#x43d;&#x44b;&#x439; &#x43a;&#x43e;&#x43d;&#x442;&#x440;&#x43e;&#x43b;&#x44c;"/>
</node>
<node CREATED="1201790233291" FOLDED="true" ID="Freemind_Link_1366009243" MODIFIED="1201790233291" TEXT="&#x41d;&#x430;&#x43f;&#x43e;&#x43c;&#x438;&#x43d;&#x430;&#x43d;&#x438;&#x435; &#x43e;&#x441;&#x442;&#x430;&#x432;&#x438;&#x442;&#x44c;">
<node CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x415;-mail"/>
<node CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x414;&#x438;&#x43a;&#x442;&#x43e;&#x444;&#x43e;&#x43d;"/>
<node CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x411;&#x43b;&#x430;&#x43d;&#x43a;"/>
<node CREATED="1201790233291" MODIFIED="1201790233291" TEXT="&#x418;&#x434;&#x438; &#x438; &#x43d;&#x430;&#x43f;&#x438;&#x448;&#x438; &#x441;&#x435;&#x431;&#x435; &#x437;&#x430;&#x434;&#x430;&#x43d;&#x438;&#x435;"/>
</node>
</node>
</node>
<node CREATED="1201790233292" FOLDED="true" ID="Freemind_Link_1209393846" MODIFIED="1201790233292" TEXT="&quot;&#x442;&#x43e;&#x442;, &#x43a;&#x442;&#x43e; &#x438;&#x434;&#x435;&#x442; &#x43f;&#x435;&#x440;&#x432;&#x44b;&#x43c;&quot;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233292" FOLDED="true" ID="Freemind_Link_1456342161" MODIFIED="1201790233292" TEXT="&#x41c;&#x430;&#x442;&#x440;&#x438;&#x446;&#x430; &#x43e;&#x446;&#x435;&#x43d;&#x43a;&#x438;">
<node CREATED="1201790233292" MODIFIED="1201790233292" TEXT="&#x41e;&#x43f;&#x440;&#x435;&#x434;&#x435;&#x43b;&#x438;&#x442;&#x44c; &#x43a;&#x440;&#x438;&#x442;&#x435;&#x440;&#x438;&#x438; (5-7)"/>
<node CREATED="1201790233292" MODIFIED="1201790233292" TEXT="&#x412;&#x437;&#x432;&#x435;&#x441;&#x438;&#x442;&#x44c; &#x43a;&#x440;&#x438;&#x442;&#x435;&#x440;&#x438;&#x438; (&#x441;&#x443;&#x43c;&#x43c;&#x430;=1)"/>
<node CREATED="1201790233292" MODIFIED="1201790233292" TEXT="&#x41e;&#x446;&#x435;&#x43d;&#x438;&#x442;&#x44c; &#x432;&#x430;&#x440;&#x438;&#x430;&#x43d;&#x442;&#x44b; &#x43f;&#x43e; &#x43a;&#x430;&#x436;&#x434;&#x43e;&#x43c;&#x443; &#x43a;&#x440;&#x438;&#x442;&#x435;&#x440;&#x438;&#x44e; (&#x43c;&#x430;&#x43a;&#x441; 7 &#x431;&#x430;&#x43b;&#x43e;&#x432;)"/>
<node CREATED="1201790233292" MODIFIED="1201790233292" TEXT="&#x412;&#x437;&#x432;&#x435;&#x448;&#x438;&#x432;&#x430;&#x435;&#x43c; &#x432;&#x430;&#x440;&#x438;&#x430;&#x43d;&#x442;&#x44b;: &#x441;&#x443;&#x43c;&#x43c;&#x430; &#x43f;&#x440;&#x43e;&#x438;&#x437;&#x432;&#x435;&#x434;&#x435;&#x43d;&#x438;&#x439; &#x43a;&#x440;&#x438;&#x442;&#x435;&#x440;&#x438;&#x44f; &#x43d;&#x430; &#x432;&#x435;&#x441;"/>
</node>
<node CREATED="1201790233292" FOLDED="true" ID="Freemind_Link_115575721" MODIFIED="1201790233292" TEXT="&#x418;&#x437; &#x438;&#x43d;&#x442;&#x443;&#x438;&#x442;&#x438;&#x432;&#x43d;&#x43e;&#x439;">
<node CREATED="1201790233292" FOLDED="true" ID="Freemind_Link_39885213" MODIFIED="1201790233292" TEXT="&#x432; &#x441;&#x438;&#x441;&#x442;&#x435;&#x43c;&#x43d;&#x443;&#x44e;">
<node CREATED="1201790233292" MODIFIED="1201790233292" TEXT="&#x444;&#x43e;&#x440;&#x43c;&#x430;&#x43b;&#x438;&#x437;&#x430;&#x446;&#x438;&#x44f;"/>
</node>
<node CREATED="1201790233292" FOLDED="true" ID="Freemind_Link_1450541304" MODIFIED="1201790233292" TEXT="&#x437;&#x430;&#x43f;&#x438;&#x441;&#x44b;&#x432;&#x430;&#x442;&#x44c;">
<node CREATED="1201790233292" MODIFIED="1201790233292" TEXT="&#x43b;&#x435;&#x433;&#x43a;&#x43e; &#x43f;&#x43e;&#x43a;&#x430;&#x437;&#x430;&#x442;&#x44c; &#x434;&#x440;&#x443;&#x433;&#x438;&#x43c;"/>
<node CREATED="1201790233292" MODIFIED="1201790233292" TEXT="&#x441;&#x43f;&#x438;&#x441;&#x43e;&#x43a; &#x43a;&#x440;&#x438;&#x442;&#x435;&#x440;&#x438;&#x435;&#x432;"/>
</node>
</node>
</node>
<node CREATED="1201790233292" FOLDED="true" ID="Freemind_Link_134641016" MODIFIED="1201790233292" TEXT="&#x41f;&#x435;&#x440;&#x432;&#x43e;&#x43e;&#x447;&#x435;&#x440;&#x435;&#x434;&#x43d;&#x44b;&#x435; &#x446;&#x435;&#x43b;&#x438;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233292" FOLDED="true" ID="Freemind_Link_1305831652" MODIFIED="1201790233292" TEXT="&#x43a;&#x440;&#x438;&#x442;&#x435;&#x440;&#x438;&#x438;">
<node CREATED="1201790233292" MODIFIED="1201790233292" TEXT="&#x431;&#x430;&#x437;&#x43e;&#x432;&#x44b;&#x435; &#x446;&#x435;&#x43d;&#x43d;&#x43e;&#x441;&#x442;&#x438;"/>
</node>
<node CREATED="1201790233292" MODIFIED="1201790233292" TEXT="&#x43d;&#x430; &#x441;&#x435;&#x439;&#x447;&#x430;&#x441;">
<icon BUILTIN="messagebox_warning"/>
</node>
<node CREATED="1201790233292" FOLDED="true" ID="Freemind_Link_75198053" MODIFIED="1201790233292" TEXT="&#x441;&#x43b;&#x435;&#x434;&#x438;&#x442;&#x44c; ">
<node CREATED="1201790233292" MODIFIED="1201790233292" TEXT="&#x437;&#x430; &#x432;&#x44b;&#x434;&#x435;&#x43b;&#x435;&#x43d;&#x438;&#x435;&#x43c; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x435;&#x43c;">
<icon BUILTIN="knotify"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1201790233305" HGAP="43" ID="Freemind_Link_663322972" MODIFIED="1201790300149" POSITION="left" TEXT="&#x418;&#x434;&#x435;&#x43e;&#x43b;&#x43e;&#x433;&#x438;&#x44f;" VSHIFT="-10">
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_1348282918" MODIFIED="1201790233305" TEXT="&#x412;&#x440;&#x435;&#x43c;&#x44f; &#x43d;&#x430; &#x422;&#x41c;">
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_776205124" MODIFIED="1201790233305" TEXT="&#x43f;&#x440;&#x430;&#x432;&#x438;&#x43b;&#x43e; 1">
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_300550607" MODIFIED="1201790233305" TEXT="&#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c;">
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_353100099" MODIFIED="1201790233305" TEXT="&#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;">
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x43e;&#x442;&#x445;&#x43e;&#x434;&#x44b;"/>
</node>
</node>
</node>
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_1540739464" MODIFIED="1201790233305" TEXT="&#x43f;&#x440;&#x430;&#x432;&#x438;&#x43b;&#x43e; 2">
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_1748607258" MODIFIED="1201790233305" TEXT="&#x447;&#x435;&#x442;&#x43a;&#x438;&#x439; &#x440;&#x438;&#x442;&#x43c;">
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="15 &#x43c;&#x438;&#x43d;&#x443;&#x442;"/>
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_1825481896" MODIFIED="1201790233305" TEXT="&#x435;&#x436;&#x435;&#x434;&#x43d;&#x435;&#x432;&#x43d;&#x43e;">
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x43c;&#x430;&#x43b;&#x435;&#x43d;&#x44c;&#x43a;&#x43e;&#x435; &#x440;&#x430;&#x437;&#x433;&#x440;&#x435;&#x431;&#x430;&#x43d;&#x438;&#x435;"/>
</node>
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_875230748" MODIFIED="1201790233305" TEXT="&#x435;&#x436;&#x435;&#x43d;&#x435;&#x434;&#x435;&#x43b;&#x44c;&#x43d;&#x43e;">
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x445;&#x440;&#x43e;&#x43d;&#x43e;&#x43c;&#x435;&#x442;&#x440;&#x430;&#x436;"/>
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x443;&#x431;&#x43e;&#x440;&#x43a;&#x430;"/>
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x43c;&#x435;&#x442;&#x43e;&#x434;&#x438;&#x43a;&#x438;"/>
</node>
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_1590271116" MODIFIED="1201790233305" TEXT="&#x435;&#x436;&#x435;&#x43a;&#x432;&#x430;&#x440;&#x442;&#x430;&#x43b;&#x44c;&#x43d;&#x43e;">
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x434;&#x438;&#x441;&#x446;&#x438;&#x43f;&#x43b;&#x438;&#x43d;&#x430;&#x440;&#x43d;&#x430;&#x44f; &#x43d;&#x435;&#x434;&#x435;&#x43b;&#x44f;"/>
</node>
</node>
</node>
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_1948421713" MODIFIED="1201790233305" TEXT="&#x412;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x438;&#x435;">
<icon BUILTIN="button_ok"/>
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x410;&#x43a;&#x442;&#x438;&#x432;"/>
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x41e;&#x43a;&#x443;&#x43f;&#x438;&#x442;&#x44c;&#x441;&#x44f;"/>
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&quot;&#x422;&#x43e;&#x447;&#x438;&#x442;&#x44c; &#x442;&#x43e;&#x43f;&#x43e;&#x440;&quot;"/>
</node>
</node>
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_425133686" MODIFIED="1201790233305" TEXT="&#x433;&#x43b;10: &#x422;&#x41c;-&#x43c;&#x430;&#x43d;&#x438;&#x444;&#x435;&#x441;&#x442;">
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_1360098444" MODIFIED="1201790233305" TEXT="&#x423;&#x440;&#x43e;&#x432;&#x43d;&#x438; &#x43c;&#x430;&#x441;&#x442;&#x435;&#x440;&#x441;&#x442;&#x432;&#x430;">
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x41e;&#x442;&#x442;&#x430;&#x447;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x438;&#x43d;&#x441;&#x442;&#x440;&#x443;&#x43c;&#x435;&#x43d;&#x442;&#x43e;&#x432;"/>
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x418;&#x437;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x435; &#x43c;&#x44b;&#x448;&#x43b;&#x435;&#x43d;&#x438;&#x44f;"/>
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_514642710" MODIFIED="1201790233305" TEXT="&#x418;&#x434;&#x435;&#x43e;&#x43b;&#x43e;&#x433;&#x438;&#x44f;">
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x416;&#x438;&#x437;&#x43d;&#x44c; &#x434;&#x430;&#x43d;&#x430; &#x442;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x43e;&#x434;&#x438;&#x43d; &#x440;&#x430;&#x437;"/>
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_104189862" MODIFIED="1201790233305" TEXT="&#x416;&#x438;&#x437;&#x43d;&#x44c; &#x441;&#x434;&#x435;&#x43b;&#x430;&#x43d;&#x430; &#x438;&#x437; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;">
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="200-400 &#x442;&#x44b;&#x441;&#x44f;&#x447; &#x447;&#x430;&#x441;&#x43e;&#x432;"/>
</node>
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="&#x414;&#x435;&#x439;&#x441;&#x442;&#x432;&#x438;&#x44f; &#x43d;&#x435;&#x43e;&#x431;&#x440;&#x430;&#x442;&#x438;&#x43c;&#x44b;"/>
</node>
</node>
<node CREATED="1201790233306" FOLDED="true" ID="Freemind_Link_938744294" MODIFIED="1201790233306" TEXT="&#x41e;&#x440;&#x433;&#x430;&#x43d;&#x438;&#x437;&#x430;&#x446;&#x438;&#x44f; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233306" FOLDED="true" ID="Freemind_Link_799929226" MODIFIED="1201790233306" TEXT="&#x43a;&#x430;&#x43a; &#x438;&#x434;&#x442;&#x438;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="&#x44d;&#x444;&#x444;&#x435;&#x43a;&#x442;&#x438;&#x432;&#x43d;&#x43e;&#x441;&#x442;&#x44c;"/>
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="&#x442;&#x435;&#x445;&#x43d;&#x43e;&#x43b;&#x43e;&#x433;&#x438;&#x44f;"/>
</node>
<node CREATED="1201790233306" FOLDED="true" ID="Freemind_Link_1572334496" MODIFIED="1201790233306" TEXT="&#x43a;&#x443;&#x434;&#x430; &#x438;&#x434;&#x442;&#x438;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="&#x441;&#x442;&#x440;&#x430;&#x442;&#x435;&#x433;&#x438;&#x44f;"/>
</node>
<node CREATED="1201790233306" FOLDED="true" ID="Freemind_Link_1156664476" MODIFIED="1201790233306" TEXT="&#x437;&#x430;&#x447;&#x435;&#x43c; &#x438;&#x434;&#x442;&#x438;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="&#x444;&#x438;&#x43b;&#x43e;&#x441;&#x43e;&#x444;&#x438;&#x44f;"/>
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="&#x43c;&#x438;&#x440;&#x43e;&#x432;&#x43e;&#x437;&#x437;&#x440;&#x435;&#x43d;&#x438;&#x435;"/>
</node>
</node>
<node CREATED="1201790233306" FOLDED="true" ID="Freemind_Link_992289024" MODIFIED="1201790233306" TEXT="&#x410;&#x43a;&#x441;&#x438;&#x43e;&#x43c;&#x44b;">
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="&#x421;&#x432;&#x43e;&#x431;&#x43e;&#x434;&#x430; &#x432;&#x44b;&#x431;&#x43e;&#x440;&#x430;"/>
<node CREATED="1201790233306" FOLDED="true" ID="Freemind_Link_1880855603" MODIFIED="1201790233306" TEXT="&#x41e;&#x442;&#x432;&#x435;&#x442;&#x441;&#x442;&#x432;&#x435;&#x43d;&#x43d;&#x43e;&#x441;&#x442;&#x44c;">
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="&#x43b;&#x438;&#x447;&#x43d;&#x430;&#x44f;"/>
</node>
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="&#x420;&#x430;&#x437;&#x432;&#x438;&#x442;&#x438;&#x435;"/>
</node>
</node>
<node CREATED="1201790233306" FOLDED="true" ID="Freemind_Link_640703221" MODIFIED="1201790233306" TEXT="&#x433;&#x43b;9: &#x422;&#x41c;-&#x431;&#x430;&#x446;&#x438;&#x43b;&#x43b;&#x430;">
<node CREATED="1201790233306" FOLDED="true" ID="Freemind_Link_1638525165" MODIFIED="1201790233306" TEXT="&#x428;&#x435;&#x444;">
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="&quot;&#x42d;&#x442;&#x43e; &#x431;&#x44b;&#x43b;&#x430; &#x435;&#x433;&#x43e; &#x438;&#x434;&#x435;&#x44f;&quot;"/>
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="&#x41f;&#x440;&#x435;&#x434;&#x44a;&#x44f;&#x432;&#x43b;&#x44f;&#x442;&#x44c; &#x438;&#x43d;&#x441;&#x442;&#x440;&#x443;&#x43c;&#x435;&#x43d;&#x442;&#x44b; &quot;&#x432; &#x434;&#x435;&#x43b;&#x435;&quot;"/>
<node CREATED="1201790233306" MODIFIED="1201790233306" TEXT="&#x41d;&#x430;&#x447;&#x438;&#x43d;&#x430;&#x442;&#x44c; &#x441; &#x43c;&#x430;&#x43b;&#x43e;&#x433;&#x43e;"/>
</node>
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_754535562" MODIFIED="1201790233307" TEXT="&#x41f;&#x43e;&#x434;&#x447;&#x438;&#x43d;&#x451;&#x43d;&#x43d;&#x44b;&#x435;">
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x41b;&#x438;&#x447;&#x43d;&#x44b;&#x439; &#x422;&#x41c;">
<icon BUILTIN="ksmiletris"/>
</node>
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_1768367604" MODIFIED="1201790233307" TEXT="&#x41a;&#x43e;&#x43c;&#x430;&#x43d;&#x434;&#x43d;&#x44b;&#x439; &#x422;&#x41c;">
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_1210540212" MODIFIED="1201790233307" TEXT="&#x414;&#x43e;&#x431;&#x440;&#x43e;&#x432;&#x43e;&#x43b;&#x44c;&#x43d;&#x43e;">
<icon BUILTIN="button_ok"/>
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x41b;&#x438;&#x447;&#x43d;&#x44b;&#x439; &#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440;"/>
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_1001645572" MODIFIED="1201790233307" TEXT="&#x41c;&#x43e;&#x442;&#x438;&#x432;&#x430;&#x446;&#x438;&#x44f;">
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_1092478878" MODIFIED="1201790233307" TEXT="&#x43f;&#x43e;&#x43d;&#x438;&#x43c;&#x430;&#x43d;&#x438;&#x435;">
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x431;&#x43e;&#x43b;&#x44c;&#x448;&#x435; &#x43a;&#x43e;&#x43c;&#x444;&#x43e;&#x440;&#x442;&#x430;"/>
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x441;&#x43d;&#x438;&#x436;&#x435;&#x43d;&#x438;&#x435; &#x440;&#x438;&#x441;&#x43a;&#x43e;&#x432;"/>
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x432;&#x44b;&#x441;&#x432;&#x43e;&#x431;&#x43e;&#x436;&#x434;&#x435;&#x43d;&#x438;&#x435; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;"/>
</node>
</node>
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_1554745467" MODIFIED="1201790233307" TEXT="&#x414;&#x432;&#x438;&#x436;&#x435;&#x43d;&#x438;&#x435;">
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x43c;&#x430;&#x43b;&#x435;&#x43d;&#x44c;&#x43a;&#x438;&#x43c;&#x438; &#x448;&#x430;&#x433;&#x430;&#x43c;&#x438;"/>
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x440;&#x438;&#x442;&#x43c;&#x438;&#x447;&#x43d;&#x43e;"/>
</node>
</node>
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_294926780" MODIFIED="1201790233307" TEXT="&#x41f;&#x440;&#x438;&#x43d;&#x443;&#x434;&#x438;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x43e;">
<icon BUILTIN="clanbomber"/>
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_1020362600" MODIFIED="1201790233307" TEXT="&#x418;&#x43d;&#x441;&#x442;&#x440;&#x443;&#x43c;&#x435;&#x43d;&#x442;&#x44b;">
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x43c;&#x430;&#x43b;&#x43e;"/>
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x43e;&#x431;&#x44f;&#x437;&#x430;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x43e;"/>
</node>
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_1660318105" MODIFIED="1201790233307" TEXT="&#x41a;&#x43d;&#x443;&#x442;&#x44b; &#x438; &#x43f;&#x440;&#x44f;&#x43d;&#x438;&#x43a;&#x438;">
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x43f;&#x440;&#x43e;&#x441;&#x442;&#x44b;&#x435;"/>
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x431;&#x44b;&#x441;&#x442;&#x440;&#x44b;&#x435;"/>
</node>
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_387968033" MODIFIED="1201790233307" TEXT="&#x41f;&#x438;&#x43b;&#x43e;&#x442;&#x43d;&#x44b;&#x435; &#x43f;&#x440;&#x43e;&#x435;&#x43a;&#x442;&#x44b;">
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x442;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x434;&#x43b;&#x44f;"/>
</node>
</node>
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_177911359" MODIFIED="1201790233307" TEXT="&#x426;&#x435;&#x43d;&#x430; &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x43f;&#x43e;&#x441;&#x447;&#x438;&#x442;&#x430;&#x442;&#x44c;"/>
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x441;&#x432;&#x43e;&#x435;"/>
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x43f;&#x43e;&#x434;&#x440;&#x430;&#x437;&#x434;&#x435;&#x43b;&#x435;&#x43d;&#x438;&#x44f;"/>
</node>
</node>
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x41e;&#x431;&#x44b;&#x447;&#x43d;&#x44b;&#x439; &#x43c;&#x435;&#x43d;&#x435;&#x434;&#x436;&#x43c;&#x435;&#x43d;&#x442;"/>
</node>
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_273565918" MODIFIED="1201790233307" TEXT="&#x41b;&#x438;&#x447;&#x43d;&#x44b;&#x435; &#x43e;&#x442;&#x43d;&#x43e;&#x448;&#x435;&#x43d;&#x438;&#x44f;">
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_1651538398" MODIFIED="1201790233307" TEXT="&#x414;&#x43e;&#x433;&#x43e;&#x432;&#x43e;&#x440;&#x438;&#x442;&#x44c;&#x441;&#x44f;">
<node CREATED="1201790233307" MODIFIED="1201790233307" TEXT="&#x412;&#x43c;&#x435;&#x441;&#x442;&#x435; &#x434;&#x435;&#x43b;&#x430;&#x435;&#x43c; &#x440;&#x430;&#x437;&#x43d;&#x43e;&#x435;"/>
<node CREATED="1201790233307" FOLDED="true" ID="Freemind_Link_1229779310" MODIFIED="1201790233307" TEXT="&#x41e;&#x442;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x435;&#x43c; &#x432;&#x440;&#x435;&#x43c;&#x44f; &#x434;&#x43b;&#x44f; &#x441;&#x435;&#x431;&#x44f;">
<node CREATED="1201790233308" MODIFIED="1201790233308" TEXT="&#x440;&#x435;&#x441;&#x443;&#x440;&#x441;&#x43d;&#x43e;&#x435; &#x437;&#x430;&#x43d;&#x44f;&#x442;&#x438;&#x435;"/>
</node>
<node CREATED="1201790233308" FOLDED="true" ID="Freemind_Link_747086433" MODIFIED="1201790233308" TEXT="&#x41f;&#x440;&#x438;&#x43d;&#x446;&#x438;&#x43f;&#x44b; &#x43f;&#x440;&#x43e;&#x433;&#x43e;&#x432;&#x430;&#x440;&#x438;&#x432;&#x430;&#x44e;&#x442;&#x441;&#x44f; &#x44f;&#x432;&#x43d;&#x43e;">
<node CREATED="1201790233308" MODIFIED="1201790233308" TEXT="&#x437;&#x430;&#x43f;&#x438;&#x441;&#x430;&#x442;&#x44c;"/>
</node>
</node>
<node CREATED="1201790233308" FOLDED="true" ID="Freemind_Link_940010532" MODIFIED="1201790233308" TEXT="&#x414;&#x435;&#x442;&#x438;">
<icon BUILTIN="button_ok"/>
<node CREATED="1201790233308" MODIFIED="1201790233308" TEXT="&#x44d;&#x43b;&#x435;&#x43c;&#x435;&#x43d;&#x442; &#x438;&#x433;&#x440;&#x44b;"/>
<node CREATED="1201790233308" MODIFIED="1201790233308" TEXT="&#x421;&#x430;&#x43c;&#x43e;&#x43c;&#x43e;&#x442;&#x438;&#x432;&#x430;&#x446;&#x438;&#x44f;"/>
<node CREATED="1201790233308" MODIFIED="1201790233308" TEXT="&#x41e;&#x431;&#x437;&#x43e;&#x440;&#x43d;&#x430;&#x44f; &#x442;&#x430;&#x431;&#x43b;&#x438;&#x446;&#x430; &#x435;&#x436;&#x435;&#x434;&#x43d;&#x435;&#x432;&#x43d;&#x44b;&#x445; &#x434;&#x435;&#x43b;"/>
<node CREATED="1201790233308" FOLDED="true" ID="Freemind_Link_802034887" MODIFIED="1201790233308" TEXT="&#x41f;&#x43b;&#x430;&#x43d;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x445;&#x43e;&#x440;&#x43e;&#x448;&#x438;&#x445; &#x43e;&#x446;&#x435;&#x43d;&#x43e;&#x43a;">
<node CREATED="1201790233308" MODIFIED="1201790233308" TEXT="&#x43f;&#x440;&#x43e;&#x430;&#x43a;&#x442;&#x438;&#x432;&#x43d;&#x43e;&#x441;&#x442;&#x44c;"/>
<node CREATED="1201790233308" MODIFIED="1201790233308" TEXT="&#x43f;&#x43e;&#x434;&#x445;&#x43e;&#x434;&#x44f;&#x449;&#x435;&#x435; &#x445;&#x43e;&#x442;&#x435;&#x43d;&#x438;&#x435;"/>
<node CREATED="1201790233308" FOLDED="true" ID="Freemind_Link_1004873535" MODIFIED="1201790233308" TEXT="&#x43f;&#x43e;&#x434;&#x433;&#x43e;&#x442;&#x43e;&#x432;&#x43a;&#x430; &#x43a; &#x44d;&#x43a;&#x437;&#x430;&#x43c;&#x435;&#x43d;&#x430;&#x43c;">
<node CREATED="1201790233308" MODIFIED="1201790233308" TEXT="&#x440;&#x438;&#x442;&#x43c;&#x438;&#x447;&#x43d;&#x43e;"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1201790233292" HGAP="35" ID="Freemind_Link_851034553" MODIFIED="1201790296982" POSITION="left" TEXT="&#x418;&#x43d;&#x441;&#x442;&#x440;&#x443;&#x43c;&#x435;&#x43d;&#x442;&#x44b; 2" VSHIFT="13">
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_766708177" MODIFIED="1201790233293" TEXT="&#x433;&#x43b;8: &#x41f;&#x43e;&#x433;&#x43b;&#x43e;&#x442;&#x438;&#x442;&#x435;&#x43b;&#x438;">
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_1741544268" MODIFIED="1201790233293" TEXT="&#x425;&#x440;&#x43e;&#x43d;&#x43e;&#x43c;&#x435;&#x442;&#x440;&#x430;&#x436;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_1426222236" MODIFIED="1201790233293" TEXT="&#x444;&#x438;&#x43a;&#x441;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x432;&#x441;&#x451;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_285923294" MODIFIED="1201790233293" TEXT="3-4 &#x43d;&#x435;&#x434;&#x435;&#x43b;&#x438;">
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_1658252219" MODIFIED="1201790233293" TEXT="&#x43f;&#x43e;&#x442;&#x43e;&#x43c; &#x43f;&#x43e;&#x432;&#x442;&#x43e;&#x440;&#x44f;&#x442;&#x44c;">
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="1-2 &#x43d;&#x435;&#x434;&#x435;&#x43b;&#x438;"/>
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="&#x432; &#x43a;&#x432;&#x430;&#x440;&#x442;&#x430;&#x43b;"/>
</node>
</node>
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_1652632388" MODIFIED="1201790233293" TEXT="&#x442;&#x43e;&#x447;&#x43d;&#x43e;&#x441;&#x442;&#x44c;">
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="5-10 &#x43c;&#x438;&#x43d;&#x443;&#x442;"/>
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="&#x434;&#x435;&#x43b;&#x430; &#x431;&#x43e;&#x43b;&#x44c;&#x448;&#x435; 5 &#x43c;&#x438;&#x43d;&#x443;&#x442;"/>
</node>
</node>
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_1979875028" MODIFIED="1201790233293" TEXT="&#x41a;&#x43e;&#x43b;&#x438;&#x447;&#x435;&#x441;&#x442;&#x432;&#x435;&#x43d;&#x43d;&#x44b;&#x435; &#x438;&#x437;&#x43c;&#x435;&#x440;&#x438;&#x442;&#x435;&#x43b;&#x438;">
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_542700823" MODIFIED="1201790233293" TEXT="&#x418;&#x437; &#x445;&#x440;&#x43e;&#x43d;&#x43e;&#x43c;&#x435;&#x442;&#x440;&#x430;&#x436;&#x430;">
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_520151183" MODIFIED="1201790233293" TEXT="&#x434;&#x43e;&#x43b;&#x433;&#x43e;&#x441;&#x440;&#x43e;&#x447;&#x43d;&#x44b;&#x435; &#x43f;&#x440;&#x43e;&#x435;&#x43a;&#x442;&#x44b;">
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="60-70% &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;"/>
</node>
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_1464626881" MODIFIED="1201790233293" TEXT="&#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x431;&#x44b;&#x43b;&#x43e; &#x434;&#x435;&#x43b;&#x435;&#x433;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c;">
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="&lt; 10% &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;"/>
</node>
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_401876575" MODIFIED="1201790233293" TEXT="&#x43f;&#x43e;&#x433;&#x43b;&#x43e;&#x442;&#x438;&#x442;&#x435;&#x43b;&#x438;">
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="10-20% &#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x438;"/>
</node>
</node>
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_56868676" MODIFIED="1201790233293" TEXT="&#x411;&#x435;&#x437; &#x445;&#x440;&#x43e;&#x43d;&#x43e;&#x43c;&#x435;&#x442;&#x440;&#x430;&#x436;&#x430;">
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_1622776714" MODIFIED="1201790233293" TEXT="&#x43d;&#x430; &#x43f;&#x440;&#x438;&#x43e;&#x440;&#x438;&#x442;&#x435;&#x442;&#x43d;&#x44b;&#x439; &#x43f;&#x440;&#x43e;&#x435;&#x43a;&#x442;">
<icon BUILTIN="ksmiletris"/>
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="&#x43f;&#x43e;&#x434;&#x43d;&#x44f;&#x442;&#x44c;"/>
</node>
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_1707332772" MODIFIED="1201790233293" TEXT="&#x43d;&#x430; &#x440;&#x435;&#x441;&#x443;&#x440;&#x441;&#x43d;&#x43e;&#x435; &#x437;&#x430;&#x43d;&#x44f;&#x442;&#x438;&#x435;">
<icon BUILTIN="ksmiletris"/>
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="&#x441;&#x43f;&#x43e;&#x440;&#x442;"/>
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="&#x445;&#x43e;&#x431;&#x431;&#x438;"/>
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="&#x43e;&#x431;&#x449;&#x435;&#x43d;&#x438;&#x435;"/>
</node>
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_1359704741" MODIFIED="1201790233293" TEXT="&#x43d;&#x430; &#x437;&#x430;&#x434;&#x435;&#x440;&#x436;&#x43a;&#x438;">
<icon BUILTIN="clanbomber"/>
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="&#x43e;&#x43f;&#x443;&#x441;&#x442;&#x438;&#x442;&#x44c;"/>
</node>
<node CREATED="1201790233293" FOLDED="true" ID="Freemind_Link_149291879" MODIFIED="1201790233293" TEXT="&#x43d;&#x430; &#x434;&#x438;&#x441;&#x43a;&#x43e;&#x43c;&#x444;&#x43e;&#x440;&#x442;&#x43d;&#x43e;&#x435; &#x43e;&#x431;&#x449;&#x435;&#x43d;&#x438;&#x435;">
<icon BUILTIN="clanbomber"/>
<node CREATED="1201790233293" MODIFIED="1201790233293" TEXT="&#x438;&#x441;&#x43a;&#x43b;&#x44e;&#x447;&#x438;&#x442;&#x44c;"/>
</node>
</node>
<node CREATED="1201790233294" FOLDED="true" ID="Freemind_Link_367553251" MODIFIED="1201790233294" TEXT="&#x413;&#x440;&#x430;&#x444;&#x438;&#x43a;">
<icon BUILTIN="button_ok"/>
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x43d;&#x430;&#x43e;&#x447;&#x43d;&#x43e;"/>
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x43e;&#x431;&#x440;&#x430;&#x442;&#x43d;&#x430;&#x44f; &#x441;&#x432;&#x44f;&#x437;&#x44c;"/>
</node>
</node>
</node>
<node CREATED="1201790233294" FOLDED="true" ID="Freemind_Link_1092591469" MODIFIED="1201790233294" TEXT="&#x420;&#x435;&#x437;&#x435;&#x440;&#x432;&#x44b;">
<icon BUILTIN="button_ok"/>
<node CREATED="1201790233294" FOLDED="true" ID="Freemind_Link_1204766857" MODIFIED="1201790233294" TEXT="&#x412; &#x442;&#x440;&#x430;&#x43d;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x435;">
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x447;&#x438;&#x442;&#x430;&#x442;&#x44c;">
<icon BUILTIN="messagebox_warning"/>
</node>
<node CREATED="1201790233294" FOLDED="true" ID="Freemind_Link_1272335240" MODIFIED="1201790233294" TEXT="&#x41e;&#x431;&#x434;&#x443;&#x43c;&#x430;&#x442;&#x44c; &#x441;&#x43f;&#x438;&#x441;&#x43e;&#x43a; &#x432;&#x43e;&#x43f;&#x440;&#x43e;&#x441;&#x43e;&#x432;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x43f;&#x43e;&#x43c;&#x435;&#x442;&#x43a;&#x438; &#x432; &#x431;&#x43b;&#x43e;&#x43a;&#x43d;&#x43e;&#x442;&#x435;"/>
</node>
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x41e;&#x442;&#x434;&#x44b;&#x445;&#x430;&#x442;&#x44c;"/>
<node CREATED="1201790233294" FOLDED="true" ID="Freemind_Link_1638298377" MODIFIED="1201790233294" TEXT="&#x423;&#x447;&#x438;&#x442;&#x44c;&#x441;&#x44f;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x41e;&#x431;&#x440;&#x430;&#x449;&#x430;&#x442;&#x44c; &#x432;&#x43d;&#x438;&#x43c;&#x430;&#x43d;&#x438;&#x435;"/>
</node>
</node>
<node CREATED="1201790233294" FOLDED="true" ID="Freemind_Link_1823822660" MODIFIED="1201790233294" TEXT="&#x41c;&#x430;&#x448;&#x438;&#x43d;&#x430;">
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x41e;&#x43f;&#x442;&#x438;&#x43c;&#x438;&#x437;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x43c;&#x430;&#x440;&#x448;&#x440;&#x443;&#x442;">
<icon BUILTIN="messagebox_warning"/>
</node>
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x430;&#x443;&#x434;&#x438;&#x43e;&#x43a;&#x43d;&#x438;&#x433;&#x438;"/>
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x417;&#x432;&#x43e;&#x43d;&#x43a;&#x438;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
<node CREATED="1201790233294" FOLDED="true" ID="Freemind_Link_414002988" MODIFIED="1201790233294" TEXT="&#x41a;&#x43e;&#x43c;&#x430;&#x43d;&#x434;&#x438;&#x440;&#x43e;&#x432;&#x43a;&#x430;">
<node CREATED="1201790233294" FOLDED="true" ID="Freemind_Link_13521335" MODIFIED="1201790233294" TEXT="&#x41a;&#x430;&#x439;&#x440;&#x43e;&#x441; &#x437;&#x430;&#x434;&#x430;&#x447;">
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x43d;&#x430;&#x43a;&#x43e;&#x43f;&#x438;&#x43b;&#x438;&#x441;&#x44c;"/>
<node CREATED="1201790233294" FOLDED="true" ID="Freemind_Link_1896562381" MODIFIED="1201790233294" TEXT="&#x41a;&#x430;&#x440;&#x442;&#x43e;&#x447;&#x43a;&#x430; &#x433;&#x43e;&#x440;&#x43e;&#x434;&#x430;">
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x41a;&#x43e;&#x43d;&#x442;&#x430;&#x43a;&#x442;&#x44b;"/>
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x41a;&#x43e;&#x43e;&#x440;&#x434;&#x438;&#x43d;&#x430;&#x442;&#x44b;"/>
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x421;&#x435;&#x440;&#x432;&#x438;&#x441;"/>
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x412;&#x430;&#x43b;&#x44e;&#x442;&#x430;"/>
<node CREATED="1201790233294" MODIFIED="1201790233294" TEXT="&#x41f;&#x443;&#x442;&#x435;&#x432;&#x44b;&#x435; &#x437;&#x430;&#x43c;&#x435;&#x442;&#x43a;&#x438;"/>
</node>
</node>
<node CREATED="1201790233294" FOLDED="true" ID="Freemind_Link_185947689" MODIFIED="1201790233294" TEXT="&#x412;&#x440;&#x435;&#x43c;&#x44f;">
<node CREATED="1201790233294" FOLDED="true" ID="Freemind_Link_1506769066" MODIFIED="1201790233294" TEXT="&#x422;&#x440;&#x430;&#x43d;&#x441;&#x43f;&#x43e;&#x440;&#x442;">
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x43c;&#x443;&#x437;&#x44b;&#x43a;&#x443;"/>
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x43b;&#x438;&#x442;&#x435;&#x440;&#x430;&#x442;&#x443;&#x440;&#x443;"/>
</node>
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x41e;&#x442;&#x434;&#x44b;&#x445;"/>
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x412;&#x435;&#x447;&#x435;&#x440;"/>
</node>
<node CREATED="1201790233295" FOLDED="true" ID="Freemind_Link_1792863728" MODIFIED="1201790233295" TEXT="&#x411;&#x430;&#x433;&#x430;&#x436;">
<node CREATED="1201790233295" FOLDED="true" ID="Freemind_Link_553864751" MODIFIED="1201790233295" TEXT="&#x41a;&#x43e;&#x43c;&#x43f;&#x43b;&#x435;&#x43a;&#x442; &#x432;&#x435;&#x449;&#x435;&#x439;">
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x433;&#x438;&#x433;&#x438;&#x435;&#x43d;&#x44b;"/>
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x442;&#x435;&#x445;.&#x43c;&#x435;&#x43b;&#x43e;&#x447;&#x438;"/>
</node>
<node CREATED="1201790233295" FOLDED="true" ID="Freemind_Link_623310260" MODIFIED="1201790233295" TEXT="&#x41c;&#x430;&#x43b;&#x43e;">
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x43d;&#x443;&#x436;&#x43d;&#x43e;&#x435;"/>
</node>
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x420;&#x443;&#x447;&#x43d;&#x430;&#x44f; &#x43a;&#x43b;&#x430;&#x434;&#x44c;"/>
</node>
<node CREATED="1201790233295" FOLDED="true" ID="Freemind_Link_847169457" MODIFIED="1201790233295" TEXT="&#x418;&#x437;&#x431;&#x44b;&#x442;&#x43e;&#x447;&#x43d;&#x430;&#x44f; &#x438;&#x43d;&#x444;&#x43e;&#x440;&#x43c;&#x430;&#x446;&#x438;&#x44f;">
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x433;&#x43e;&#x442;&#x43e;&#x432; &#x43a;&#x43e; &#x432;&#x441;&#x435;&#x43c;&#x443;"/>
</node>
</node>
</node>
<node CREATED="1201790233295" FOLDED="true" ID="Freemind_Link_765256506" MODIFIED="1201790233295" TEXT="&#x424;&#x43e;&#x440;&#x441;-&#x43c;&#x430;&#x436;&#x43e;&#x440;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233295" FOLDED="true" ID="Freemind_Link_666156285" MODIFIED="1201790233295" TEXT="&#x41a;&#x43e;&#x43c;&#x43f;&#x44c;&#x44e;&#x442;&#x435;&#x440;">
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x434;&#x443;&#x43c;&#x430;&#x442;&#x44c; &#x438; &#x431;&#x435;&#x437;"/>
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x438;&#x43d;&#x442;&#x435;&#x440;&#x43d;&#x435;&#x442; &#x43a;&#x43b;&#x443;&#x431;"/>
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="backup"/>
</node>
<node CREATED="1201790233295" FOLDED="true" ID="Freemind_Link_515399577" MODIFIED="1201790233295" TEXT="&#x422;&#x435;&#x43b;&#x435;&#x444;&#x43e;&#x43d;">
<node CREATED="1201790233295" FOLDED="true" ID="Freemind_Link_895622605" MODIFIED="1201790233295" TEXT="&#x437;&#x430;&#x43f;&#x438;&#x441;&#x43d;&#x430;&#x44f; &#x43a;&#x43d;&#x438;&#x433;&#x430;">
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="backup"/>
</node>
</node>
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x41c;&#x430;&#x448;&#x438;&#x43d;&#x430;"/>
</node>
<node CREATED="1201790233295" FOLDED="true" ID="Freemind_Link_985779010" MODIFIED="1201790233295" TEXT="&#x421;&#x43e;&#x432;&#x435;&#x449;&#x430;&#x43d;&#x438;&#x44f;">
<icon BUILTIN="flag"/>
<node CREATED="1201790233295" FOLDED="true" ID="Freemind_Link_1164110540" MODIFIED="1201790233295" TEXT="&#x424;&#x43e;&#x440;&#x43c;&#x430;&#x442;">
<node CREATED="1201790233295" FOLDED="true" ID="Freemind_Link_1796581235" MODIFIED="1201790233295" TEXT="&#x41c;&#x43e;&#x437;&#x433;&#x43e;&#x432;&#x43e;&#x439; &#x448;&#x442;&#x443;&#x440;&#x43c;">
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x440;&#x435;&#x448;&#x438;&#x442;&#x44c; &#x43f;&#x440;&#x43e;&#x431;&#x43b;&#x435;&#x43c;&#x443;"/>
</node>
<node CREATED="1201790233295" FOLDED="true" ID="Freemind_Link_1669485646" MODIFIED="1201790233295" TEXT="&#x41f;&#x43b;&#x430;&#x43d;&#x451;&#x440;&#x43a;&#x430;-&#x43e;&#x43f;&#x435;&#x440;&#x430;&#x442;&#x438;&#x432;&#x43a;&#x430;">
<node CREATED="1201790233295" MODIFIED="1201790233295" TEXT="&#x441;&#x43a;&#x43e;&#x43e;&#x440;&#x434;&#x438;&#x43d;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x434;&#x435;&#x439;&#x441;&#x442;&#x432;&#x438;&#x44f;"/>
</node>
<node CREATED="1201790233296" FOLDED="true" ID="Freemind_Link_583167394" MODIFIED="1201790233296" TEXT="&#x421;&#x43e;&#x432;&#x435;&#x449;&#x430;&#x43d;&#x438;&#x435;">
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x43d;&#x430;&#x43f;&#x440;&#x430;&#x432;&#x438;&#x442;&#x44c; &#x440;&#x430;&#x437;&#x432;&#x438;&#x442;&#x438;&#x435;"/>
</node>
</node>
<node CREATED="1201790233296" FOLDED="true" ID="Freemind_Link_567818404" MODIFIED="1201790233296" TEXT="&#x423;&#x447;&#x430;&#x441;&#x442;&#x43d;&#x438;&#x43a;&#x438;">
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x432; &#x43c;&#x430;&#x43b;&#x44b;&#x445; &#x433;&#x440;&#x443;&#x43f;&#x43f;&#x430;&#x445;"/>
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x43e;&#x431;&#x449;&#x435;&#x435;"/>
<node CREATED="1201790233296" FOLDED="true" ID="Freemind_Link_300049796" MODIFIED="1201790233296" TEXT="&#x43e;&#x43f;&#x440;&#x435;&#x434;&#x435;&#x43b;&#x438;&#x442;&#x44c;">
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x41b;&#x438;&#x434;&#x435;&#x440;&#x430;"/>
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x421;&#x435;&#x43a;&#x440;&#x435;&#x442;&#x430;&#x440;&#x44f;"/>
</node>
</node>
<node CREATED="1201790233296" FOLDED="true" ID="Freemind_Link_839288158" MODIFIED="1201790233296" TEXT="&#x421;&#x43f;&#x438;&#x441;&#x43e;&#x43a; &#x432;&#x43e;&#x43f;&#x440;&#x43e;&#x441;&#x43e;&#x432;">
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x43f;&#x440;&#x438;&#x43e;&#x440;&#x438;&#x442;&#x435;&#x442;&#x44b;"/>
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x43e;&#x431;&#x449;&#x435;&#x435; &#x432;&#x440;&#x435;&#x43c;&#x44f;"/>
</node>
<node CREATED="1201790233296" FOLDED="true" ID="Freemind_Link_1661279171" MODIFIED="1201790233296" TEXT="&#x414;&#x43b;&#x438;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x43e;&#x441;&#x442;&#x44c;">
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x441;&#x43b;&#x435;&#x434;&#x438;&#x442;&#x44c;"/>
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x43e;&#x442;&#x432;&#x435;&#x442;&#x441;&#x442;&#x432;&#x435;&#x43d;&#x43d;&#x44b;&#x439; &#x437;&#x430; &#x432;&#x440;&#x435;&#x43c;&#x44f;"/>
</node>
<node CREATED="1201790233296" FOLDED="true" ID="Freemind_Link_24491919" MODIFIED="1201790233296" TEXT="&#x41e;&#x440;&#x433;&#x430;&#x43d;&#x438;&#x437;&#x430;&#x446;&#x438;&#x44f;">
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x41e;&#x431;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43a;&#x430;"/>
<node CREATED="1201790233296" FOLDED="true" ID="Freemind_Link_342539798" MODIFIED="1201790233296" TEXT="&#x41e;&#x431;&#x43e;&#x440;&#x443;&#x434;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435;">
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x43f;&#x440;&#x43e;&#x435;&#x43a;&#x442;&#x43e;&#x440;"/>
</node>
<node CREATED="1201790233296" FOLDED="true" ID="Freemind_Link_733500764" MODIFIED="1201790233296" TEXT="&#x418;&#x43d;&#x444;&#x43e;&#x440;&#x43c;&#x430;&#x446;&#x438;&#x43e;&#x43d;&#x43d;&#x44b;&#x435; &#x43c;&#x430;&#x442;&#x435;&#x440;&#x438;&#x430;&#x43b;&#x44b;">
<node CREATED="1201790233296" FOLDED="true" ID="Freemind_Link_220164033" MODIFIED="1201790233296" TEXT="&#x440;&#x430;&#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x430;">
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x43a;&#x440;&#x430;&#x442;&#x43a;&#x43e;"/>
</node>
<node CREATED="1201790233296" FOLDED="true" ID="Freemind_Link_1225391629" MODIFIED="1201790233296" TEXT="&#x437;&#x430;&#x442;&#x440;&#x435;&#x431;&#x43e;&#x432;&#x430;&#x442;&#x44c;">
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x440;&#x435;&#x448;&#x435;&#x43d;&#x438;&#x435; &#x43f;&#x440;&#x43e;&#x431;&#x43b;&#x435;&#x43c;&#x44b;"/>
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="2-3 &#x432;&#x430;&#x440;&#x438;&#x430;&#x43d;&#x442;&#x430;"/>
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x437;&#x430; &#x441;&#x443;&#x442;&#x43a;&#x438; &#x434;&#x43e; &#x43d;&#x430;&#x447;&#x430;&#x43b;&#x430;"/>
</node>
</node>
</node>
<node CREATED="1201790233296" FOLDED="true" ID="Freemind_Link_725268507" MODIFIED="1201790233296" TEXT="&#x41d;&#x430;&#x43e;&#x447;&#x43d;&#x43e;&#x441;&#x442;&#x438;">
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x421;&#x445;&#x435;&#x43c;&#x44b;"/>
<node CREATED="1201790233296" MODIFIED="1201790233296" TEXT="&#x41c;&#x43e;&#x436;&#x43d;&#x43e; &#x444;&#x43e;&#x442;&#x43e;&#x433;&#x440;&#x430;&#x444;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c;"/>
</node>
<node CREATED="1201790233296" FOLDED="true" ID="Freemind_Link_1690703688" MODIFIED="1201790233296" TEXT="&#x41f;&#x440;&#x43e;&#x442;&#x43e;&#x43a;&#x43e;&#x43b;">
<node CREATED="1201790233297" FOLDED="true" ID="Freemind_Link_74596594" MODIFIED="1201790233297" TEXT="&#x43f;&#x440;&#x438;&#x43d;&#x44f;&#x442;&#x44b;&#x435; &#x440;&#x435;&#x448;&#x435;&#x43d;&#x438;&#x44f;">
<node CREATED="1201790233297" MODIFIED="1201790233297" TEXT="&#x41f;&#x435;&#x440;&#x432;&#x44b;&#x439; &#x448;&#x430;&#x433;"/>
<node CREATED="1201790233297" MODIFIED="1201790233297" TEXT="&#x421;&#x440;&#x43e;&#x43a;"/>
<node CREATED="1201790233297" MODIFIED="1201790233297" TEXT="&#x41e;&#x442;&#x432;&#x435;&#x442;&#x441;&#x442;&#x432;&#x435;&#x43d;&#x43d;&#x44b;&#x439;"/>
</node>
<node CREATED="1201790233297" MODIFIED="1201790233297" TEXT="&#x440;&#x430;&#x437;&#x43e;&#x441;&#x43b;&#x430;&#x442;&#x44c;"/>
</node>
</node>
</node>
<node CREATED="1201790233297" FOLDED="true" ID="Freemind_Link_1473359087" MODIFIED="1201790263810" TEXT="&#x433;&#x43b;7: &#x418;&#x43d;&#x444;&#x43e;&#x440;&#x43c;&#x430;&#x446;&#x438;&#x44f;" VSHIFT="13">
<node CREATED="1201790233297" FOLDED="true" ID="Freemind_Link_1498017210" MODIFIED="1201790233297" TEXT="&#x412;&#x445;&#x43e;&#x434;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233297" FOLDED="true" ID="Freemind_Link_1807916046" MODIFIED="1201790233297" TEXT="&#x427;&#x438;&#x442;&#x430;&#x442;&#x44c;">
<icon BUILTIN="ksmiletris"/>
<node CREATED="1201790233297" FOLDED="true" ID="Freemind_Link_1130103751" MODIFIED="1201790233297" TEXT="&#x440;&#x438;&#x442;&#x43c;">
<node CREATED="1201790233297" MODIFIED="1201790233297" TEXT="&#x443;&#x43c;&#x43d;&#x430;&#x44f; &#x43a;&#x43d;&#x438;&#x433;&#x430; &#x432; &#x43d;&#x435;&#x434;&#x435;&#x43b;&#x44e;"/>
<node CREATED="1201790233297" MODIFIED="1201790233297" TEXT="4-6 &#x432; &#x43c;&#x435;&#x441;&#x44f;&#x446;"/>
</node>
<node CREATED="1201790233297" MODIFIED="1201790233297" TEXT="&#x43f;&#x43e;&#x434; &#x437;&#x430;&#x434;&#x430;&#x447;&#x443; (&#x43f;&#x440;&#x43e;&#x435;&#x43a;&#x442;)">
<icon BUILTIN="ksmiletris"/>
</node>
<node CREATED="1201790233297" FOLDED="true" ID="Freemind_Link_282161378" MODIFIED="1201790233297" TEXT="&#x440;&#x435;&#x43a;&#x43e;&#x43c;&#x435;&#x43d;&#x434;&#x430;&#x446;&#x438;&#x438;">
<node CREATED="1201790233297" FOLDED="true" ID="Freemind_Link_632423320" MODIFIED="1201790233297" TEXT="&#x434;&#x43e;&#x441;&#x442;&#x443;&#x43f; &#x43a; &#x432;&#x430;&#x436;&#x43d;&#x43e;&#x43c;&#x443;">
<node CREATED="1201790233297" MODIFIED="1201790233297" TEXT="&#x432;&#x44b;&#x43f;&#x438;&#x441;&#x43a;&#x438;">
<icon BUILTIN="ksmiletris"/>
</node>
<node CREATED="1201790233297" MODIFIED="1201790233297" TEXT="&#x43d;&#x43e;&#x43c;&#x435;&#x440;&#x430; &#x441;&#x442;&#x440;&#x430;&#x43d;&#x438;&#x446;"/>
<node CREATED="1201790233297" MODIFIED="1201790233297" TEXT="&#x43a;&#x43e;&#x43f;&#x438;&#x438; &#x441;&#x442;&#x440;&#x430;&#x43d;&#x438;&#x446;"/>
</node>
<node CREATED="1201790233297" FOLDED="true" ID="Freemind_Link_685024629" MODIFIED="1201790233297" TEXT="&#x43f;&#x440;&#x438;&#x43c;&#x435;&#x43d;&#x438;&#x442;&#x44c; &#x441;&#x440;&#x430;&#x437;&#x443;">
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x43f;&#x43e;&#x442;&#x43e;&#x43c; &#x43f;&#x440;&#x43e;&#x434;&#x43e;&#x43b;&#x436;&#x438;&#x442;&#x44c; &#x447;&#x438;&#x442;&#x430;&#x442;&#x44c;"/>
</node>
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_1559058149" MODIFIED="1201790233298" TEXT="&#x440;&#x430;&#x441;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x442;&#x44c; &#x43f;&#x440;&#x438;&#x43e;&#x440;&#x438;&#x442;&#x435;&#x442;&#x44b;">
<icon BUILTIN="ksmiletris"/>
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x433;&#x43b;&#x430;&#x432;&#x43d;&#x44b;&#x435; &#x433;&#x43b;&#x430;&#x432;&#x44b;"/>
</node>
</node>
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_1804094931" MODIFIED="1201790233298" TEXT="&#x441;&#x43f;&#x438;&#x441;&#x43e;&#x43a;">
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x43e;&#x442; &#x430;&#x432;&#x442;&#x43e;&#x440;&#x438;&#x442;&#x435;&#x442;&#x43e;&#x432;"/>
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x43f;&#x440;&#x438;&#x43e;&#x440;&#x438;&#x442;&#x435;&#x442;&#x44b;"/>
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x43f;&#x43e;&#x434;&#x440;&#x44f;&#x434; &#x440;&#x430;&#x437;&#x43d;&#x43e;&#x439; &#x442;&#x435;&#x43c;&#x430;&#x442;&#x438;&#x43a;&#x438;">
<icon BUILTIN="ksmiletris"/>
</node>
</node>
</node>
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_145663450" MODIFIED="1201790233298" TEXT="&#x417;&#x43e;&#x43c;&#x431;&#x43e;&#x42f;&#x449;&#x438;&#x43a;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_1651297703" MODIFIED="1201790233298" TEXT="&#x417;&#x430;&#x43f;&#x438;&#x441;&#x44b;&#x432;&#x430;&#x442;&#x44c; &#x43f;&#x435;&#x440;&#x435;&#x434;&#x430;&#x447;&#x438;">
<icon BUILTIN="button_ok"/>
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x441;&#x43c;&#x43e;&#x442;&#x440;&#x435;&#x442;&#x44c; &#x43a;&#x43e;&#x433;&#x434;&#x430; &#x443;&#x434;&#x43e;&#x431;&#x43d;&#x43e;"/>
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x43d;&#x443;&#x436;&#x43d;&#x44b;&#x435;"/>
</node>
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x427;&#x451;&#x442;&#x43a;&#x43e; &#x43e;&#x433;&#x440;&#x430;&#x43d;&#x438;&#x447;&#x438;&#x442;&#x44c; &#x432;&#x440;&#x435;&#x43c;&#x44f;">
<icon BUILTIN="button_cancel"/>
</node>
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x424;&#x43e;&#x43d; - &#x44d;&#x442;&#x43e; &#x43c;&#x443;&#x437;&#x44b;&#x43a;&#x430;, &#x430; &#x43d;&#x435; &#x442;&#x435;&#x43b;&#x438;&#x43a;"/>
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_1902299434" MODIFIED="1201790233298" TEXT="&#x421;&#x43f;&#x440;&#x44f;&#x442;&#x430;&#x442;&#x44c; &#x43f;&#x443;&#x43b;&#x44c;&#x442;">
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x437;&#x430;&#x43f;&#x43f;&#x438;&#x43d;&#x433; - &#x43d;&#x430;&#x440;&#x43a;&#x43e;&#x442;&#x430;">
<icon BUILTIN="clanbomber"/>
</node>
</node>
</node>
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_1927555760" MODIFIED="1201790233298" TEXT="&#x41c;&#x44b;&#x43b;&#x43e;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_1152622387" MODIFIED="1201790233298" TEXT="&#x421;&#x43b;&#x435;&#x43f;&#x430;&#x44f; &#x43f;&#x435;&#x447;&#x430;&#x442;&#x44c;">
<icon BUILTIN="button_ok"/>
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x441;&#x432;&#x43e;&#x431;&#x43e;&#x434;&#x430;"/>
</node>
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_1896618517" MODIFIED="1201790233298" TEXT="&#x421;&#x43f;&#x430;&#x43c;-&#x444;&#x438;&#x43b;&#x44c;&#x442;&#x440;">
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x43e;&#x442;&#x434;&#x435;&#x43b;&#x44c;&#x43d;&#x44b;&#x439; &#x440;&#x430;&#x431;&#x43e;&#x447;&#x438;&#x439; &#x44f;&#x449;&#x438;&#x43a;"/>
</node>
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_1388723322" MODIFIED="1201790233298" TEXT="&#x41f;&#x440;&#x43e;&#x432;&#x435;&#x440;&#x44f;&#x442;&#x44c; &#x43f;&#x43e;&#x447;&#x442;&#x443; &#x432;&#x440;&#x443;&#x447;&#x43d;&#x443;&#x44e;">
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x435;&#x441;&#x43b;&#x438; &#x43d;&#x435; &#x43d;&#x430;&#x434;&#x43e; &#x441;&#x440;&#x43e;&#x447;&#x43d;&#x43e;&#x441;&#x442;&#x438;"/>
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x43e;&#x442;&#x43a;&#x43b;&#x44e;&#x447;&#x438;&#x442;&#x44c; &#x432;&#x441;&#x43f;&#x43b;&#x44b;&#x432;&#x430;&#x43b;&#x43a;&#x443;"/>
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_538666947" MODIFIED="1201790233298" TEXT="3-4 &#x440;&#x430;&#x437;&#x430; &#x432; &#x434;&#x435;&#x43d;&#x44c;">
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x438;&#x437;&#x432;&#x435;&#x441;&#x442;&#x43d;&#x43e; &#x43a;&#x43e;&#x43b;&#x43b;&#x435;&#x433;&#x430;&#x43c;"/>
</node>
</node>
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_1631139333" MODIFIED="1201790233298" TEXT="&#x410;&#x432;&#x442;&#x43e;&#x43c;&#x430;&#x442;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x430;&#x44f; &#x441;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x43a;&#x430;">
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_914234673" MODIFIED="1201790233298" TEXT="&#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x435;&#x43d;&#x438;&#x435; &#x43f;&#x43e;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233298" MODIFIED="1201790233298" TEXT="&#x430;&#x434;&#x440;&#x435;&#x441;&#x443; &#x43e;&#x442;&#x43f;&#x440;&#x430;&#x432;&#x438;&#x442;&#x435;&#x43b;&#x44f;"/>
<node CREATED="1201790233298" FOLDED="true" ID="Freemind_Link_118964586" MODIFIED="1201790233298" TEXT="&#x442;&#x435;&#x43c;&#x435;">
<node CREATED="1201790233299" MODIFIED="1201790233299" TEXT="&#x440;&#x430;&#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438;"/>
<node CREATED="1201790233299" FOLDED="true" ID="Freemind_Link_389180433" MODIFIED="1201790233299" TEXT="&#x43c;&#x435;&#x442;&#x43a;&#x438;">
<icon BUILTIN="flag"/>
<node CREATED="1201790233299" MODIFIED="1201790233299" TEXT="&#x434;&#x43e;&#x433;&#x43e;&#x432;&#x43e;&#x440; &#x441; &#x43a;&#x43e;&#x43b;&#x43b;&#x435;&#x433;&#x430;&#x43c;&#x438;"/>
</node>
</node>
</node>
<node CREATED="1201790233299" FOLDED="true" ID="Freemind_Link_1997091563" MODIFIED="1201790233299" TEXT="&#x43f;&#x430;&#x43f;&#x43a;&#x438;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233299" MODIFIED="1201790233299" TEXT="&#x41a;&#x43e;&#x43d;&#x442;&#x440;&#x43e;&#x43b;&#x44c; &#x435;&#x436;&#x435;&#x434;&#x43d;&#x435;&#x432;&#x43d;&#x44b;&#x439;"/>
<node CREATED="1201790233299" MODIFIED="1201790233299" TEXT="&#x41a;&#x43e;&#x43d;&#x442;&#x440;&#x43e;&#x43b;&#x44c;  &#x435;&#x436;&#x435;&#x43d;&#x435;&#x434;&#x435;&#x43b;&#x44c;&#x43d;&#x44b;&#x439;"/>
<node CREATED="1201790233299" MODIFIED="1201790233299" TEXT="&#x421;&#x43f;&#x440;&#x430;&#x432;&#x43e;&#x447;&#x43d;&#x43e;&#x435;"/>
<node CREATED="1201790233299" MODIFIED="1201790233299" TEXT="&#x41a;&#x430;&#x439;&#x440;&#x43e;&#x441;&#x43d;&#x44b;&#x435;">
<icon BUILTIN="flag"/>
</node>
</node>
<node CREATED="1201790233302" FOLDED="true" ID="Freemind_Link_1999968525" MODIFIED="1201790233302" TEXT="&#x432;&#x438;&#x437;&#x443;&#x430;&#x43b;&#x44c;&#x43d;&#x43e;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233302" MODIFIED="1201790233302" TEXT="&#x446;&#x432;&#x435;&#x442;"/>
<node CREATED="1201790233302" MODIFIED="1201790233302" TEXT="&#x448;&#x440;&#x438;&#x444;&#x442;"/>
</node>
</node>
</node>
</node>
<node CREATED="1201790233302" FOLDED="true" ID="Freemind_Link_1790394324" MODIFIED="1201790233302" TEXT="&#x425;&#x440;&#x430;&#x43d;&#x435;&#x43d;&#x438;&#x435;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_1805913459" MODIFIED="1201790233303" TEXT="&#x414;&#x43e;&#x43a;&#x443;&#x43c;&#x435;&#x43d;&#x442;&#x43e;&#x432;">
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_1445643429" MODIFIED="1201790233303" TEXT="&#x421;&#x442;&#x440;&#x443;&#x43a;&#x442;&#x443;&#x440;&#x430;">
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x432;&#x44b;&#x440;&#x430;&#x449;&#x438;&#x432;&#x430;&#x442;&#x44c;"/>
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x430;&#x441;&#x444;&#x430;&#x43b;&#x44c;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x433;&#x430;&#x437;&#x43e;&#x43d;&#x430;"/>
</node>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_504347430" MODIFIED="1201790233303" TEXT="&#x421;&#x43e;&#x437;&#x434;&#x430;&#x43d;&#x438;&#x435;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_1835685502" MODIFIED="1201790233303" TEXT="&#x41c;&#x435;&#x441;&#x442;&#x43e; &#x445;&#x430;&#x43e;&#x441;&#x430;">
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x412;&#x445;&#x43e;&#x434;&#x44f;&#x449;&#x438;&#x435;"/>
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x420;&#x430;&#x441;&#x445;&#x43e;&#x434;&#x44b; &#x43d;&#x430; &#x43f;&#x43e;&#x438;&#x441;&#x43a;"/>
</node>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_1864692126" MODIFIED="1201790233303" TEXT="&#x428;&#x430;&#x433; &#x43f;&#x43e;&#x440;&#x44f;&#x434;&#x43a;&#x430;">
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x412;&#x44b;&#x447;&#x43b;&#x435;&#x43d;&#x44f;&#x435;&#x43c;"/>
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x41b;&#x435;&#x433;&#x43a;&#x43e; &#x43e;&#x442;&#x434;&#x435;&#x43b;&#x44f;&#x435;&#x43c;&#x44b;&#x439;"/>
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x422;&#x438;&#x43f; &#x434;&#x43e;&#x43a;&#x443;&#x43c;&#x435;&#x43d;&#x442;&#x43e;&#x432;"/>
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x41d;&#x43e;&#x432;&#x430;&#x44f; &#x43f;&#x430;&#x43f;&#x43a;&#x443;"/>
</node>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_1048182833" MODIFIED="1201790233303" TEXT="&#x41c;&#x435;&#x441;&#x442;&#x43e; &#x43f;&#x43e;&#x440;&#x44f;&#x434;&#x43a;&#x430;">
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x422;&#x435; &#x447;&#x451;&#x442;&#x43a;&#x43e;"/>
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x422;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x442;&#x443;&#x434;&#x430;"/>
</node>
</node>
</node>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_436863759" MODIFIED="1201790233303" TEXT="&#x41c;&#x44b;&#x441;&#x43b;&#x438; &#x438; &#x438;&#x434;&#x435;&#x438;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_868599379" MODIFIED="1201790233303" TEXT="&#x41c;&#x430;&#x442;&#x435;&#x440;&#x438;&#x430;&#x43b;&#x438;&#x437;&#x430;&#x446;&#x438;&#x44f;">
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x437;&#x430;&#x43f;&#x438;&#x441;&#x430;&#x442;&#x44c;"/>
</node>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_1900425169" MODIFIED="1201790233303" TEXT="&#x41a;&#x430;&#x440;&#x442;&#x43e;&#x442;&#x435;&#x43a;&#x430;">
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x43e;&#x434;&#x43d;&#x430; &#x43c;&#x44b;&#x441;&#x43b;&#x44c; - &#x43e;&#x434;&#x438;&#x43d; &#x43d;&#x43e;&#x441;&#x438;&#x442;&#x435;&#x43b;&#x44c;"/>
</node>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_497582325" MODIFIED="1201790233303" TEXT="&#x41c;&#x435;&#x441;&#x442;&#x43e; &#x445;&#x430;&#x43e;&#x441;&#x430;">
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x441;&#x442;&#x44b;&#x43a;&#x43e;&#x432;&#x43a;&#x438;"/>
</node>
</node>
</node>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_699617193" MODIFIED="1201790233303" TEXT="&#x412;&#x43d;&#x438;&#x43c;&#x430;&#x43d;&#x438;&#x435;">
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_486708256" MODIFIED="1201790233303" TEXT="&#x421;&#x442;&#x440;&#x443;&#x43a;&#x442;&#x443;&#x440;&#x430;">
<icon BUILTIN="flag"/>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_1680830323" MODIFIED="1201790233303" TEXT="&#x421;&#x43e;&#x437;&#x43d;&#x430;&#x43d;&#x438;&#x435;">
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_1624852377" MODIFIED="1201790233303" TEXT="1">
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x444;&#x43e;&#x43a;&#x443;&#x441;"/>
</node>
</node>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_1572837997" MODIFIED="1201790233303" TEXT="&#x41f;&#x440;&#x435;&#x434;&#x441;&#x43e;&#x437;&#x43d;&#x430;&#x43d;&#x438;&#x435;">
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="5-9"/>
</node>
<node CREATED="1201790233303" FOLDED="true" ID="Freemind_Link_1939719663" MODIFIED="1201790233303" TEXT="&#x41f;&#x43e;&#x434;&#x441;&#x43e;&#x437;&#x43d;&#x430;&#x43d;&#x438;&#x435;">
<node CREATED="1201790233303" MODIFIED="1201790233303" TEXT="&#x43c;&#x43d;&#x43e;&#x433;&#x43e;"/>
</node>
</node>
<node CREATED="1201790233304" FOLDED="true" ID="Freemind_Link_1456583377" MODIFIED="1201790233304" TEXT="&#x420;&#x430;&#x431;&#x43e;&#x447;&#x438;&#x439; &#x441;&#x442;&#x43e;&#x43b;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233304" FOLDED="true" ID="Freemind_Link_1025372473" MODIFIED="1201790233304" TEXT="&#x446;&#x435;&#x43d;&#x442;&#x440; &#x432;&#x43d;&#x438;&#x43c;&#x430;&#x43d;&#x438;&#x44f;">
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x43c;&#x43e;&#x43d;&#x438;&#x442;&#x43e;&#x440;"/>
</node>
<node CREATED="1201790233304" FOLDED="true" ID="Freemind_Link_1225063013" MODIFIED="1201790233304" TEXT="&#x43e;&#x431;&#x43b;&#x430;&#x441;&#x442;&#x44c; &#x431;&#x43b;&#x438;&#x436;&#x430;&#x439;&#x448;&#x435;&#x433;&#x43e; &#x432;&#x43d;&#x438;&#x43c;&#x430;&#x43d;&#x438;&#x44f;">
<node CREATED="1201790233304" FOLDED="true" ID="Freemind_Link_152150498" MODIFIED="1201790233304" TEXT="&#x441;&#x442;&#x438;&#x43a;&#x435;&#x440;&#x44b;">
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x43c;&#x435;&#x43d;&#x44c;&#x448;&#x435; 9"/>
</node>
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x440;&#x443;&#x447;&#x43a;&#x430;"/>
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x431;&#x43b;&#x43e;&#x43a;&#x43d;&#x43e;&#x442;"/>
</node>
<node CREATED="1201790233304" FOLDED="true" ID="Freemind_Link_742318716" MODIFIED="1201790233304" TEXT="&#x43e;&#x431;&#x43b;&#x430;&#x441;&#x442;&#x44c; &#x434;&#x430;&#x43b;&#x435;&#x43a;&#x43e;&#x433;&#x43e; &#x432;&#x43d;&#x438;&#x43c;&#x430;&#x43d;&#x438;&#x44f;">
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x441;&#x442;&#x438;&#x43a;&#x435;&#x440;&#x44b;"/>
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x432;&#x438;&#x437;&#x438;&#x442;&#x43a;&#x438;"/>
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x43a;&#x430;&#x43d;&#x446;&#x435;&#x43b;&#x44f;&#x440;&#x438;&#x44f;"/>
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x441;&#x43f;&#x440;&#x430;&#x432;&#x43e;&#x447;&#x43d;&#x438;&#x43a;&#x438;"/>
</node>
</node>
<node CREATED="1201790233304" FOLDED="true" ID="Freemind_Link_1550328917" MODIFIED="1201790233304" TEXT="&#x41d;&#x430;&#x43a;&#x43e;&#x43f;&#x438;&#x442;&#x435;&#x43b;&#x438;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233304" FOLDED="true" ID="Freemind_Link_1802494784" MODIFIED="1201790233304" TEXT="&#x412;&#x445;&#x43e;&#x434;&#x44f;&#x449;&#x435;&#x439;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x440;&#x430;&#x431;&#x43e;&#x447;&#x435;&#x435;"/>
</node>
<node CREATED="1201790233304" FOLDED="true" ID="Freemind_Link_1303444849" MODIFIED="1201790233304" TEXT="&#x418;&#x441;&#x445;&#x43e;&#x434;&#x44f;&#x449;&#x435;&#x439;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x432;&#x435;&#x447;&#x435;&#x440;&#x43e;&#x43c;"/>
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x440;&#x430;&#x441;&#x441;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x43a;&#x430;"/>
</node>
<node CREATED="1201790233304" FOLDED="true" ID="Freemind_Link_1002617451" MODIFIED="1201790233304" TEXT="&#x41b;&#x43e;&#x442;&#x43a;&#x438;">
<icon BUILTIN="forward"/>
<node CREATED="1201790233304" FOLDED="true" ID="Freemind_Link_800327879" MODIFIED="1201790233304" TEXT="&#x41a;&#x43e;&#x43d;&#x442;&#x440;&#x43e;&#x43b;&#x44c;&#x43d;&#x430;&#x44f; &#x433;&#x440;&#x443;&#x43f;&#x43f;&#x430;">
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x435;&#x436;&#x435;&#x434;&#x43d;&#x435;&#x432;&#x43d;&#x44b;&#x439;"/>
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x435;&#x436;&#x435;&#x43d;&#x435;&#x434;&#x435;&#x43b;&#x44c;&#x43d;&#x44b;&#x439;"/>
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x435;&#x436;&#x435;&#x43c;&#x435;&#x441;&#x44f;&#x447;&#x43d;&#x44b;&#x439;"/>
</node>
<node CREATED="1201790233304" FOLDED="true" ID="Freemind_Link_598165231" MODIFIED="1201790233304" TEXT="&#x41a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x430;&#x44f; &#x433;&#x440;&#x443;&#x43f;&#x43f;&#x430;">
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x43a;&#x430;&#x439;&#x440;&#x43e;&#x441;&#x44b;"/>
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x430;&#x43a;&#x442;&#x443;&#x430;&#x43b;&#x44c;&#x43d;&#x44b;&#x435;"/>
</node>
</node>
</node>
<node CREATED="1201790233304" FOLDED="true" ID="Freemind_Link_877419515" MODIFIED="1201790233304" TEXT="&#x414;&#x43e;&#x441;&#x43a;&#x438;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1201790233304" MODIFIED="1201790233304" TEXT="&#x41f;&#x43b;&#x430;&#x43d;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f;"/>
<node CREATED="1201790233305" FOLDED="true" ID="Freemind_Link_1112880380" MODIFIED="1201790233305" TEXT="&#x434;&#x43e;&#x43f;&#x43e;&#x43b;&#x43d;&#x438;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x44b;&#x435;">
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x444;&#x43e;&#x442;&#x43e;&#x433;&#x440;&#x430;&#x444;&#x438;&#x438;"/>
<node CREATED="1201790233305" MODIFIED="1201790233305" TEXT="&#x43c;&#x43e;&#x442;&#x438;&#x432;&#x430;&#x446;&#x438;&#x44f;">
<icon BUILTIN="ksmiletris"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
